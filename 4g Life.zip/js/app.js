function toggleFunc() {
	document.getElementById("user-dropdown").classList.toggle("show");
}

window.onclick = function(event) {
  	if (!event.target.matches('.user-name')) {
	    var dropdowns = document.getElementsByClassName("user-dropdown");
	    var i;
	    for (i = 0; i < dropdowns.length; i++) {
	      	var openDropdown = dropdowns[i];
	      	if (openDropdown.classList.contains('show')) {
	        	openDropdown.classList.remove('show');
	      	}
		}
  	}
}


jQuery(document).ready(function($) {

	$('input[name="radio-group"]').change(function(){
		$('input[name="radio-group"]').each(function(index, el) {
            $('.popupShow').attr({
				'data-toggle': '',
				'data-target': '#',
				'data-whatever': ''
			});
			$(el).parents('tr').find('.restricted-icon').css('display', 'inline-block');
            $(el).parents('tr').find('.restricted-icon').prev('a').removeClass('popupShow');
		});
		
        if ($(this).prop('checked')) {
            $(this).parents('tr').find('.restricted-icon').css('display', 'none');
            $(this).parents('tr').find('.restricted-icon').prev('a').addClass('popupShow');
            $('.popupShow').attr({
				'data-toggle': 'modal',
				'data-target': '#deleteConfirm',
				'data-whatever': '@getbootstrap'
			});
        }     
    });

  
	$('#selectpicker-chart').change(function(){
		var sellectEllem = $("#selectpicker-chart").children("option").filter(":selected").text();
		if (sellectEllem === 'Year') {
			$('#chart-item-two > canvas').css('display', 'none');
			$('#chart-item-three > canvas').css('display', 'none');
			$('#chart-item-two > canvas').css('display', 'block');
		}
		else if (sellectEllem !== 'Day') {
			$('#chart-item-two > canvas').css('display', 'none');
		}
		if (sellectEllem === 'Day') {
			$('#chart-item-two > canvas').css('display', 'none');
			$('#chart-item-one > canvas').css('display', 'none');
			$('#chart-item-three > canvas').css('display', 'block');
		}
		else if (sellectEllem !== 'Day') {
			$('#chart-item-three > canvas').css('display', 'none');
		}
		if (sellectEllem === 'Month') {
			$('#chart-item-two > canvas').css('display', 'none');
			$('#chart-item-three > canvas').css('display', 'none');
			$('#chart-item-one > canvas').css('display', 'block');
		} 
		else if (sellectEllem !== 'Month') {
			$('#chart-item-one > canvas').css('display', 'none');
		}
	})

	$('#chart-item-three > canvas').css('display', 'none');
	$('#chart-item-two > canvas').css('display', 'none');
	$('#chart-item-one > canvas').css('display', 'block');


	$(".toggle-password").click(function() {
		$(this).toggleClass("fa-eye fa-eye-slash");
		var input = $($(this).attr("toggle"));
		if (input.attr("type") == "password") {
			input.attr("type", "text");
		} else {
		input.attr("type", "password");
		}
	});

	$("#checkAll").click(function () {
	    $(".check-for-all").prop('checked', $(this).prop('checked'));
	});

	$(function() {
		$('#report-data-table input[type="radio"]').change(function() {
            let who = $(this).prop('id');
            let checked = $(this).prop('checked') ? 'checked' : 'unchecked';
            $("input[type='radio']").removeAttr('checked');
            $("#" + who).attr('checked', 'true');
		});
	});
	

	var checkboxes = $("input[type='checkbox']"),
	    submitButt = $(".checkedButton");

	checkboxes.click(function() {
	    submitButt.attr("disabled", !checkboxes.is(":checked"));
	});

	$("#register-link").on('click', function() {
		$('#register').css('display', 'block');
		$('#signin').css('display', 'none');
	});

	$("#signin-link").on('click', function() {
		$('#register').css('display', 'none');
		$('#signin').css('display', 'block');
	});

	$('.chart').easyPieChart({
	    easing: 'easeOutCirc',
	    barColor: '#0586D7  ',
	    trackColor: '#f9f9f9  ',
	    scaleColor:false,
	    scaleLength: 5,
	    percent:67,
	    lineCap: 'round',
	    lineWidth: 8, 
	    size: 110, 
	    animate: {duration: 1000,enabled: true},
	    onStep: function(from, to, percent) {$(this.el).find('.percent').text(Math.round(percent));}
	  });

	var olldNew = [];
	$('a[data-target="#Change-pass"]').on('click', function() {
		var inputstore = $(this).parents('.input-group').find('#inputPassword').val();
		olldNew.push(inputstore);
		$('#old-password').val(olldNew[olldNew.length - 2]);
		$('#new-password').val(inputstore);
		if(olldNew.length > 2) {
			olldNew.shift();
		}
	})
	
});

window.addEventListener('load', function () {
	chartOne();
	chartTwo();
	chartThree();
}, false);

function chartOne() {
	var ctx = document.getElementById("chart-one").getContext("2d"); 
	var gradient = ctx.createLinearGradient(0, 0, 0, 130);
	    gradient.addColorStop(0, 'rgba(66, 141, 255, 0.97)');   
	    gradient.addColorStop(1, 'rgba(16, 156, 241, 0.09)');
	var data = {
	    labels : ["1 Dec", "8 Dec", "15 Dec", "25 Dec", "29 Dec"],
	    datasets: [{
		    fillColor : gradient,
		    strokeColor : "#109CF1",
		    pointColor : "#109CF1",
		    pointStrokeColor : "#109CF1",
		    pointHighlightFill: "#fff",
		    pointHighlightStroke: "#109CF1",
		    data : [30.3, 102.4, 52.2, 149.4, 50.5, 200,]
	    }]
	};

	var options = {
	    responsive: true,
	    datasetStrokeWidth : 3,
	    tooltipFillColor: "rgba(0,0,0,0.8)",
	    tooltipFontStyle: "bold",
	    tooltipTemplate: "<%if (label){%><%=label + ' hod' %>: <%}%><%= value %>",
	    scaleLabel : "<%= Number(value).toFixed(0).replace('.', ',')%>"
	};
	var newlilne = new Chart(ctx).Line(data, options);
}

function chartTwo() {
	var ctx = document.getElementById("chart-two").getContext("2d"); 
	var gradient = ctx.createLinearGradient(0, 0, 0, 130);
	    gradient.addColorStop(0, 'rgba(66, 41, 255, 0.97)');   
	    gradient.addColorStop(1, 'rgba(36, 156, 241, 0.09)');
	var data = {
	    labels : ["1 Dec", "8 Dec", "15 Dec", "25 Dec", "29 Dec"],
	    datasets: [{
		    fillColor : gradient,
		    strokeColor : "#109CF1",
		    pointColor : "#109CF1",
		    pointStrokeColor : "#109CF1",
		    pointHighlightFill: "#fff",
		    pointHighlightStroke: "#109CF1",
		    data : [60.3, 10.4, 152.2, 149.4, 70.5, 200,]
	    }]
	};

	var options = {
	    responsive: true,
	    datasetStrokeWidth : 3,
	    tooltipFillColor: "rgba(0,0,0,0.8)",
	    tooltipFontStyle: "bold",
	    tooltipTemplate: "<%if (label){%><%=label + ' hod' %>: <%}%><%= value %>",
	    scaleLabel : "<%= Number(value).toFixed(0).replace('.', ',')%>"
	};
	var newlilne = new Chart(ctx).Line(data, options);
}



function chartThree() {
	var ctx = document.getElementById("chart-three").getContext("2d"); 
	var gradient = ctx.createLinearGradient(0, 0, 0, 130);
	    gradient.addColorStop(0, 'rgba(26, 41, 155, 0.97)');   
	    gradient.addColorStop(1, 'rgba(6, 56, 41, 0.09)');
	var data = {
	    labels : ["1 Dec", "8 Dec", "15 Dec", "25 Dec", "29 Dec"],
	    datasets: [{
		    fillColor : gradient,
		    strokeColor : "#109CF1",
		    pointColor : "#109CF1",
		    pointStrokeColor : "#109CF1",
		    pointHighlightFill: "#fff",
		    pointHighlightStroke: "#109CF1",
		    data : [90.3, 142.4, 72.2, 49.4, 150.5, 200,]
	    }]
	};

	var options = {
	    responsive: true,
	    datasetStrokeWidth : 3,
	    tooltipFillColor: "rgba(0,0,0,0.8)",
	    tooltipFontStyle: "bold",
	    tooltipTemplate: "<%if (label){%><%=label + ' hod' %>: <%}%><%= value %>",
	    scaleLabel : "<%= Number(value).toFixed(0).replace('.', ',')%>"
	};
	var newlilne = new Chart(ctx).Line(data, options);
}



var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  	showSlides(slideIndex += n);
}
function currentSlide(n) {
  	showSlides(slideIndex = n);
}
function showSlides(n) {
	var i;
	var slides = document.getElementsByClassName("progress-intro");
	if (n > slides.length) {slideIndex = 4}    
	if (n < 1) {slideIndex = 1}
	for (i = 0; i < slides.length; i++) {
	  	slides[i].style.display = "none";  
	}
	slides[slideIndex-1].style.display = "block";  
}

function openNav() {
  	document.getElementById("dashboard-sidemenu").style.left = "0";
}

function closeNav() {
  	document.getElementById("dashboard-sidemenu").style.left = "-268px";
}


(function() {
  'use strict';
  window.addEventListener('load', function() {
    var forms = document.getElementsByClassName('needs-validation');
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();


