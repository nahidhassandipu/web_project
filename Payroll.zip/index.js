const express = require('express');
const path = require('path');
const exphbs = require('express-handlebars');
const mysql = require('mysql');
const app = express();
const db = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'dcsa',
    multipleStatements: true
});

getEmployeeID = [];
storeId = [];

storeMemberid = undefined;

db.connect((err) => {
    let sql = `SELECT id FROM employee; SELECT memberid FROM salary ORDER BY memberid ASC LIMIT 1`;
    db.query(sql, (err, data) => {
        getEmployeeID = data[0];
        storeId = [];
        storeMemberid = data[1];
        getEmployeeID.forEach((item, index) => {
            storeId.push(parseInt(getEmployeeID[index].id));
        })
        if(err) throw err;
        console.log('Database connected...')
    })
});
app.engine('handlebars', exphbs({
    defaultLayout: 'main',
    layoutsDir: __dirname + '/views/layouts/',
    partialsDir: __dirname + '/views/partials/'
}));
app.set('view engine', 'handlebars');
// Handlebars.registerPartial('content', '{{name}}')
// Body parser middleware
app.use(express.json());
app.use(express.urlencoded({extended: false}));

function checkResNumValue(requestData, defaultVal) {
    if( typeof(requestData) == 'undefined' ) { 
        return defaultVal
    } else { 
        return requestData;
    }
}

// Limit set for employeesalary page 
employee_salary_limit = 10;
employee_salary_offset = 10;

// Limit set for allsalary page 
allsalary_limit = 10;
allsalary_offset = 10;

// Limit set for allemployee page 
allemployee_limit = 10;
allemployee_offset = 10;

// Store sql filter query 
storeResult = undefined;
// Limit set for filter page 
filter_limit = 10;
filter_offset = 10;

// Store sql search query 
searchResult = undefined;
getID = undefined;
// Limit set for search page 
search_limit = 10;
search_offset = 10;

// Store Sql Employee Salary
storeSqlEmployeeSalary = undefined;
storeSqlEmployee = undefined;
storeSqlSalary = undefined;

app.get('/', (req, res) => {
    res.render( 'home', { title: 'Welcome to home page' })
})
app.get('/allemployee', (req, res) => {
    allemployee_limit = 0;
    allemployee_offset = 10;

    let sqlEmployee = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join FROM employee`;

    let sql = `${sqlEmployee} ORDER BY id LIMIT 10; ${sqlEmployee} ORDER BY id DESC LIMIT 1`;
    db.query(sql, (err, rows) => {
        if(err) throw err;
        storeEmployeeId = rows[1];
        storeSqlEmployee = `${sqlEmployee} ORDER BY id`
        let nextAllemdisabled = false;
        let prevdisabled = true;
        if (rows[0].length < 10 || rows[0][9].id == storeEmployeeId[0].id) {
            nextAllemdisabled = true
        }
        res.render('allemployee', { 
            title: 'Details of employees', 
            rows: rows[0],
            prevdisabled,
            nextAllemdisabled
        })
    })
});
app.get('/allemployees_prev', (req, res) => {

    let prevdisabled = false;
    
    if (allemployee_limit <= 10 ) {
        prevdisabled = true;
        allemployee_limit = 0;
        allemployee_offset = 10;
    } else { allemployee_limit -= 10; prevdisabled = false;}

    if (storeSqlEmployee != undefined) {
        let sql = `${storeSqlEmployee} LIMIT ${allemployee_limit}, ${allemployee_offset}`;

        db.query(sql, (err, rows) => {
            if(err) throw err;
            res.render('allemployee', { 
                title: 'Details of employees', 
                rows,
                prevdisabled
            })
        })
    } else {
        res.render('wrongurl', {
            msg:'Invalid Request',
            elements: 'true',
            elements2 : 'false',
            followingURL: '/allemployee',
            followingURLtext: 'All Employees'
        })
    }
})
app.get('/allemployees_next', (req, res) => {
    let bool = true;
    if (bool == true) { allemployee_limit += 10 } 

    let nextAllemdisabled = false;

    if (storeSqlEmployee != undefined) {
        let sql = `${storeSqlEmployee} LIMIT ${allemployee_limit}, ${allemployee_offset}`;
        db.query(sql, (err, rows) => {
            if(err) throw err;
            if (rows.length < 10 || rows[9].id == storeEmployeeId[0].id) {
                nextAllemdisabled = true;
            }
            if (rows.length < 1) {
                bool = false;
                allemployee_limit = rows.length;
                allemployee_offset = rows.length;
                return false
            } else { bool = true }
            res.render('allemployee', { 
                title: 'Details of employees', 
                rows,
                nextAllemdisabled, 
            })
        })
    } else {
        res.render('wrongurl', {
            msg:'Invalid Request',
            elements: 'true',
            elements2 : 'false',
            followingURL: '/allemployee',
            followingURLtext: 'All Employees'
        })
    }
})
app.get('/allsalary', (req, res) => {
    allsalary_limit = 0;
    allsalary_offset = 10;
    
    let sqlSalary = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join, DATE_FORMAT(date_of_salary_payment, '%D %M %Y') AS date_of_salary_payment FROM employee INNER JOIN salary ON employee.id = salary.employeeid`;
    
    let sql = `${sqlSalary} ORDER BY memberid DESC LIMIT 10; ${sqlSalary} ORDER BY memberid ASC LIMIT 1`;
    
    db.query(sql, (err, rows) => {
        if(err) throw err;
        storeTransactionId = rows[1],
        storeSqlSalary = `${sqlSalary} ORDER BY memberid DESC`
        let nextSalarydisabled = false;
        let prevSalarydisabled = true;
        if (rows[0].length < 10 || rows[0][9].memberid == storeTransactionId[0].memberid) {
            nextSalarydisabled = true
        }
        res.render('allsalary', { 
            title: 'Details of salaries',
            rows: rows[0],
            prevSalarydisabled,
            nextSalarydisabled
        })
    })
});
app.get('/allsalary_prev', (req, res) => {
    
    let prevSalarydisabled = false;
    
    if (allsalary_limit <= 10 ) {
        prevSalarydisabled = true;
        allsalary_limit = 0;
        allsalary_offset = 10;
    } else { allsalary_limit -= 10;prevSalarydisabled = false; }

    if (storeSqlSalary != undefined) {
        let sql = `${storeSqlSalary} LIMIT ${allsalary_limit}, ${allsalary_offset}`;
        db.query(sql, (err, rows) => {
            if(err) throw err;
            res.render('allsalary', { 
                title: 'Details of salaries',
                rows,
                prevSalarydisabled 
            })
        })
    } else {
        res.render('wrongurl', {
            msg:'Invalid Request',
            elements: 'true',
            elements2 : 'false',
            followingURL: '/allsalary',
            followingURLtext: 'All Salary'
        })
    }
})
app.get('/allsalary_next', (req, res) => {
    
    let nextSalarydisabled = false;
    
    let bool = true;
    if (bool == true) { allsalary_limit += 10 } 
    
    if (storeSqlSalary != undefined) {
        let sql = `${storeSqlSalary} LIMIT ${allsalary_limit}, ${allsalary_offset}`;
        db.query(sql, (err, rows) => {
            if(err) throw err;
            if (rows.length < 10 || rows[9].memberid == storeTransactionId[0].memberid) {
                nextSalarydisabled = true
            }
            if (rows.length < 1) {
                bool = false;
                allsalary_limit = rows.length;
                allsalary_offset = rows.length;
                return false
            } else { bool = true }
            res.render('allsalary', { 
                title: 'Details of salaries',
                rows,
                nextSalarydisabled
            })
        })
    } else {
        res.render('wrongurl', {
            msg:'Invalid Request',
            elements: 'true',
            elements2 : 'false',
            followingURL: '/allsalary',
            followingURLtext: 'All Salary'
        })
    }
})
app.get('/employeesalary', (req, res) => {
    employee_salary_limit = 0;
    employee_salary_offset = 10;
    
    let sqlEmployeeSalary = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join, DATE_FORMAT(date_of_salary_payment, '%D %M %Y') AS date_of_salary_payment FROM employee INNER JOIN salary ON employee.id = salary.employeeid`

    let sql = `${sqlEmployeeSalary} ORDER BY memberid DESC LIMIT 10; ${sqlEmployeeSalary} ORDER BY memberid ASC LIMIT 1`;
    db.query(sql, (err, rows) => {
        if(err) throw err;
        storeTransactionIdTwo = rows[1];
        storeSqlEmployeeSalary = `${sqlEmployeeSalary} ORDER BY memberid DESC`;
        let nextSalaryEmdisabled = false;
        let prevSalaryEmdisabled = true;
        if (rows[0].length < 10 || rows[0][9].memberid == storeTransactionIdTwo[0].memberid) {
            nextSalaryEmdisabled = true
        }
        res.render('employeesalary', { 
            title: 'Details of employees with salaries', 
            rows: rows[0],
            nextSalaryEmdisabled,
            prevSalaryEmdisabled
        })
    })
});
app.get('/employeesalary_prev', (req, res) => {
    
    let prevSalaryEmdisabled = false;
    
    if (employee_salary_limit <= 10 ) {
        prevSalaryEmdisabled = true;
        employee_salary_limit = 0;
        employee_salary_offset = 10;
    } else { employee_salary_limit -= 10;prevSalaryEmdisabled = false; }

    if (storeSqlEmployeeSalary != undefined) {
        let sql = `${storeSqlEmployeeSalary} LIMIT ${employee_salary_limit}, ${employee_salary_offset}`;

        db.query(sql, (err, rows) => {
            if(err) throw err;
            res.render('employeesalary', { 
                title: 'Details of employees with salaries',
                rows,
                prevSalaryEmdisabled,
            })
        })
    } else {
        res.render('wrongurl', {
            msg:'Invalid Request',
            elements: 'true',
            elements2 : 'false',
            followingURL: '/employeesalary',
            followingURLtext: 'Employees and Salaries'
        })
    }
})
app.get('/employeesalary_next', (req, res) => {
    
    let nextSalaryEmdisabled = false;

    let bool = true;
    if (bool == true) { employee_salary_limit += 10 } 
    
    if (storeSqlEmployeeSalary != undefined) {
        let sql = `${storeSqlEmployeeSalary} LIMIT ${employee_salary_limit}, ${employee_salary_offset}`;
    
        db.query(sql, (err, rows) => {
            if(err) throw err;
            if (rows.length < 10 || rows[9].memberid == storeTransactionIdTwo[0].memberid) {
                nextSalaryEmdisabled = true
            }
            if (rows.length < 1) {
                bool = false;
                employee_salary_limit = rows.length;
                employee_salary_offset = rows.length;
                return false
            } else { bool = true }
            res.render('employeesalary', { 
                title: 'Details of employees with salaries',
                rows,
                nextSalaryEmdisabled
            })
        })
    } else {
        res.render('wrongurl', {
            msg:'Invalid Request',
            elements: 'true',
            elements2 : 'false',
            followingURL: '/employeesalary',
            followingURLtext: 'Employees and Salaries'
        })
    }
})
app.get('/searchid', (req, res) => {
    
    search_limit = 0;
    search_offset = 10;

    const qst = {id: req.query.id}
    
    const checkId = row => row.id === parseInt(qst.id);
    
    let startPoint, endPoint, midPoint, position;
    
    startPoint = 1;
    endPoint = storeId.length;

    while(startPoint <= endPoint) {
        midPoint = Math.floor((startPoint + endPoint) / 2)
        if(storeId[0] == qst.id) {
            position = 0;
            break;
        }
        if(storeId[midPoint] == qst.id) {
            position = midPoint;
            break;
        }
        if (storeId[endPoint] == qst.id) {
            position = endPoint;
            break;
        }
        else if(storeId[midPoint] < qst.id) {
            startPoint = midPoint + 1
        }
        else {
            endPoint = midPoint - 1
        }
    }

    if (position == undefined ) { res.render( 'notexist', { msg : `${qst.id}` }) }

    else {
        let searchGenerate = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join, DATE_FORMAT(date_of_salary_payment, '%D %M %Y') AS date_of_salary_payment FROM employee INNER JOIN salary ON employee.id = salary.employeeid WHERE employee.id = ${storeId[position]}`

        let sql = `${searchGenerate} ORDER BY memberid DESC LIMIT 10; ${searchGenerate} ORDER BY memberid ASC LIMIT 1`;

        db.query(sql, (err, rows) => {
            if(err) throw err;
            const found = rows[0].some(checkId);
            searchResult = `${searchGenerate} ORDER BY memberid DESC`;;
            getID = qst.id;
            storeSearchRs = rows[1];
            if(found) {
                let nextSearchdisabled = false;
                let prevSearchdisabled = true;
                if (rows[0].length < 10 || rows[0][9].memberid == storeSearchRs[0].memberid) {
                    nextSearchdisabled = true
                }
                res.render( 'search', {
                    title: `Details employee ID - ${storeId[position]}`,
                    rows: rows[0].filter(checkId),
                    prevSearchdisabled,
                    nextSearchdisabled
                })
            } else { 
                res.render( 'notexist', { msg : qst.id })
            } 
        })
    }
});
app.get('/search_prev', (req, res) => {
    
    let prevSearchdisabled = false

    if (search_limit <= 10 ) {
        search_limit = 0;
        prevSearchdisabled = true;
        search_offset = 10;
    } else { search_limit -= 10; prevSearchdisabled = false }
    
    if (searchResult != undefined) {
        let sql = `${searchResult} LIMIT ${search_limit}, ${search_offset}`;
    
        db.query(sql, (err, rows) => {
            if(err) throw err;
            if (rows.length < 10 || rows[9].memberid == storeSearchRs[0].memberid) {
                prevSearchdisabled = true
            }
            res.render('search', { 
                title: `Details employee ID - ${getID}`,
                rows,
                prevSearchdisabled
            })
        })
    } else {
        res.render('wrongurl', {
            msg:'Please Search With A Valid Employee ID First',
            elements: 'false',
            elements2 : 'true'
        })
    }
})
app.get('/search_next', (req, res) => {
    
    let nextSearchdisabled = false;
    let bool = true;
    if (bool == true) { search_limit += 10 } 

    if (searchResult != undefined) {
        let sql = `${searchResult} LIMIT ${search_limit}, ${search_offset}`;
        
        db.query(sql, (err, rows) => {
            if(err) throw err;
            if (rows.length < 10 || rows[9].memberid == storeSearchRs[0].memberid) {
                nextSearchdisabled = true
            }
            if (rows.length < 1) {
                bool = false;
                search_limit = rows.length;
                search_offset = rows.length;
                return false
            } else { bool = true }
            res.render('search', { 
                title: `Details employee ID - ${getID}`, 
                rows,
                nextSearchdisabled
            })
        })
    } else {
        res.render('wrongurl', {
            msg:'Please Search With A Valid Employee ID First',
            elements: 'false',
            elements2 : 'true'
        })
    }
})
app.get('/employeeid', (req, res) => {
    filterEmployee = {
        id: checkResNumValue(req.query.id, 'employee.id') ? checkResNumValue(req.query.id, 'employee.id') : 0,
        date_of_salary_payment: checkResNumValue(req.query.date_of_salary_payment, 'salary.date_of_salary_payment')
    }
    let sql = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join, DATE_FORMAT(date_of_salary_payment, '%D %M %Y') AS date_of_salary_payment FROM employee INNER JOIN salary ON employee.id = salary.employeeid WHERE employee.id = ${filterEmployee.id} AND salary.date_of_salary_payment = ${filterEmployee.date_of_salary_payment != 'salary.date_of_salary_payment' ? "'" + filterEmployee.date_of_salary_payment + "'" : filterEmployee.date_of_salary_payment } ORDER BY memberid DESC LIMIT 1`
    db.query(sql, (err, results) => {
        if(err) throw err
        res.render( 'employeeid', { 
            title: 'Employee details',
            results
        })
    })
});
app.get('/filter', (req, res) => { 
    let sql = `DELETE year FROM year; INSERT INTO year(year) SELECT DISTINCT YEAR(salary.date_of_salary_payment) FROM salary ORDER BY YEAR(salary.date_of_salary_payment)`;
    db.query(sql, (err, groups) => {
        if(err) throw err;
        res.render( 'filter', { 
            title: 'Make a filter search',
        })
    })
})
app.get('/filtersearch', (req, res) => { 
    filter_limit = 0;
    filter_offset = 10;

    filterItem = {
        memberid: checkResNumValue(req.query.memberid, 'salary.memberid'),
        id: checkResNumValue(req.query.id, 'employee.id'),
        name: checkResNumValue(req.query.name, 'employee.name'),
        designation: checkResNumValue(req.query.designation, 'employee.designation'),
        employee_group: checkResNumValue(req.query.employee_group, 'employee.employee_group'),
        division : checkResNumValue(req.query.division, 'employee.division'),
        phone: checkResNumValue(req.query.phone, 'employee.phone'),
        email: checkResNumValue(req.query.email, 'employee.email'),
        dob: checkResNumValue(req.query.dob, 'employee.dob'),
        date_of_salary_payment: checkResNumValue(req.query.date_of_salary_payment, 'salary.date_of_salary_payment'),
        specific_month: checkResNumValue(req.query.specific_month, 'MONTHNAME(salary.date_of_salary_payment)'),
        specific_year: checkResNumValue(req.query.specific_year, 'YEAR(salary.date_of_salary_payment)'),
        date_of_join: checkResNumValue(req.query.date_of_join, 'employee.date_of_join'),
        qualification: checkResNumValue(req.query.qualification, 'employee.qualification'),
        experience_year: checkResNumValue(req.query.experience_year, 'employee.experience_year'),
        quality: checkResNumValue(req.query.quality, 'employee.quality'),
        basic_salary: checkResNumValue(req.query.basic_salary, `salary.basic_salary`),
        gross_salary: checkResNumValue(req.query.gross_salary, `salary.gross_salary`),
        net_salary: checkResNumValue(req.query.net_salary, `salary.net_salary`),
        number_of_increments: checkResNumValue(req.query.number_of_increments, `salary.number_of_increments`),
        per_increment_amount: checkResNumValue(req.query.per_increment_amount, `salary.per_increment_amount`),
        total_increments_amounts: checkResNumValue(req.query.total_increments_amounts, `salary.total_increments_amounts`),
        allowance: checkResNumValue(req.query.allowance, `salary.allowance`),
        medical: checkResNumValue(req.query.medical, `salary.medical`),
        special_bonus: checkResNumValue(req.query.special_bonus, `salary.special_bonus`),
        provident_fund: checkResNumValue(req.query.provident_fund, `salary.provident_fund`),
        benevolent_fund: checkResNumValue(req.query.benevolent_fund, `salary.benevolent_fund`),
        conveyance: checkResNumValue(req.query.conveyance, `salary.conveyance`),
        gas: checkResNumValue(req.query.gas, `salary.gas`),
        electricity: checkResNumValue(req.query.electricity, `salary.electricity`),
        water: checkResNumValue(req.query.water, `salary.water`),
        insurance: checkResNumValue(req.query.insurance, `salary.insurance`),
        tel_fax_internet_bill: checkResNumValue(req.query.tel_fax_internet_bill, `salary.tel_fax_internet_bill`),
        revenue: checkResNumValue(req.query.revenue, `salary.revenue`),
        welfare: checkResNumValue(req.query.welfare, `salary.welfare`),
        contribution: checkResNumValue(req.query.contribution, `salary.contribution`),
        over_time_hrs: checkResNumValue(req.query.over_time_hrs, `salary.over_time_hrs`),
        Per_hrs_pay_rate: checkResNumValue(req.query.Per_hrs_pay_rate, `salary.Per_hrs_pay_rate`),
        total_overtime_hrs_rate: checkResNumValue(req.query.total_overtime_hrs_rate, `salary.total_overtime_hrs_rate`)
    }

    let coreSql = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join, DATE_FORMAT(date_of_salary_payment, '%D %M %Y') AS date_of_salary_payment FROM employee INNER JOIN salary ON employee.id = salary.employeeid WHERE salary.memberid = ${filterItem.memberid} AND employee.id = ${filterItem.id} AND employee.name = ${filterItem.name != 'employee.name' ? "'" + filterItem.name + "'" : filterItem.name } AND employee.employee_group = ${filterItem.employee_group != 'employee.employee_group' ? "'" + filterItem.employee_group + "'" : filterItem.employee_group } AND employee.division = ${filterItem.division != 'employee.division' ? "'" + filterItem.division + "'" : filterItem.division} AND employee.designation = ${filterItem.designation != 'employee.designation' ? "'" + filterItem.designation + "'" : filterItem.designation } AND employee.phone = ${filterItem.phone != 'employee.phone' ? "'" + filterItem.phone + "'" : filterItem.phone } AND employee.email = ${filterItem.email != 'employee.email' ? "'" + filterItem.email + "'" : filterItem.email } AND employee.qualification = ${filterItem.qualification != 'employee.qualification' ? "'" + filterItem.qualification + "'" : filterItem.qualification } AND employee.experience_year = ${filterItem.experience_year != 'employee.experience_year' ? "'" + filterItem.experience_year + "'" : filterItem.experience_year } AND employee.quality = ${filterItem.quality != 'employee.quality' ? "'" + filterItem.quality + "'" : filterItem.quality } AND employee.dob = ${filterItem.dob != 'employee.dob' ? "'" + filterItem.dob + "'" : filterItem.dob } AND employee.date_of_join = ${filterItem.date_of_join != 'employee.date_of_join' ? "'" + filterItem.date_of_join + "'" : filterItem.date_of_join } AND salary.date_of_salary_payment = ${filterItem.date_of_salary_payment != 'salary.date_of_salary_payment' ? "'" + filterItem.date_of_salary_payment + "'" : filterItem.date_of_salary_payment } AND MONTHNAME(salary.date_of_salary_payment) = ${filterItem.specific_month != 'MONTHNAME(salary.date_of_salary_payment)' ? "'" + filterItem.specific_month + "'" : 'MONTHNAME(salary.date_of_salary_payment)'} AND YEAR(salary.date_of_salary_payment) = ${filterItem.specific_year != 'YEAR(salary.date_of_salary_payment)' ? "'" + filterItem.specific_year + "'" : 'YEAR(salary.date_of_salary_payment)'} AND salary.basic_salary = ${filterItem.basic_salary} AND salary.number_of_increments = ${filterItem.number_of_increments} AND salary.per_increment_amount = ${filterItem.per_increment_amount} AND salary.total_increments_amounts = ${filterItem.total_increments_amounts} AND salary.allowance = ${filterItem.allowance} AND salary.medical = ${filterItem.medical} AND salary.special_bonus = ${filterItem.special_bonus} AND salary.provident_fund = ${filterItem.provident_fund} AND salary.benevolent_fund = ${filterItem.benevolent_fund} AND salary.conveyance = ${filterItem.conveyance} AND salary.gas = ${filterItem.gas} AND salary.electricity = ${filterItem.electricity} AND salary.water = ${filterItem.water} AND salary.insurance = ${filterItem.insurance} AND salary.tel_fax_internet_bill = ${filterItem.tel_fax_internet_bill} AND salary.revenue = ${filterItem.revenue} AND salary.welfare = ${filterItem.welfare} AND salary.contribution = ${filterItem.contribution} AND salary.gross_salary = ${filterItem.gross_salary} AND salary.net_salary = ${filterItem.net_salary} AND salary.over_time_hrs = ${filterItem.over_time_hrs} AND salary.Per_hrs_pay_rate = ${filterItem.Per_hrs_pay_rate} AND salary.total_overtime_hrs_rate = ${filterItem.total_overtime_hrs_rate}`

    let sql = `${coreSql} ORDER BY memberid DESC LIMIT 10; ${coreSql} ORDER BY memberid ASC LIMIT 1`
    
    let sqlLimitless = `${coreSql} ORDER BY memberid DESC`

    // get the current url
    // filterURL = req.protocol + '://' + req.get('host') + req.originalUrl;

    db.query(sql, (err, results) => {
        if(err) {
            res.render( '404', { msg : `Nothig Really found` })
        }
        else {
            storeResult = sqlLimitless;
            storeMemberid = results[1];
            let nextFiterdisabled = false;
            let filterPrevdisabled = true;
            if (results[0].length < 10 || results[0][9].memberid == storeMemberid[0].memberid) {
                nextFiterdisabled = true
            }
            res.render( 'filtersearch', { 
                title: `Filter results`,
                results: results[0],
                filterPrevdisabled,
                nextFiterdisabled
            })
        }
    })
});
app.get('/filter_prev', (req, res) => {

    let filterPrevdisabled = false;
    
    if (filter_limit <= 10 ) {
        filterPrevdisabled = true;
        filter_limit = 0;
        filter_offset = 10;
    } else { filter_limit -= 10; filterPrevdisabled = false; }
    
    if (storeResult != undefined) {
        let sql = `${storeResult} LIMIT ${filter_limit}, ${filter_offset}`;
    
        db.query(sql, (err, results) => {
            if(err) throw err;
            res.render('filtersearch', { 
                title: 'Filter results', 
                results,
                filterPrevdisabled
            })
        })
    } else {
        res.render('wrongurl', {
            msg:'Generate A Filter Search First To Get The Proper Result',
            followingURLtext: 'Filte Search',
            followingURL: '/filter',
            elements: 'true',
            elements2: 'false',
        })
    }
})
app.get('/filter_next', (req, res) => {
    let bool = true;
    if (bool == true) { filter_limit += 10 } 
    
    let nextFiterdisabled = false;
    if (storeResult != undefined) {
        let sql = `${storeResult} LIMIT ${filter_limit}, ${filter_offset}`;
        db.query(sql, (err, results) => {
            if(err) throw err;

            if (results.length < 10 || results[9].memberid == storeMemberid[0].memberid) {
                nextFiterdisabled = true
            }
            if (results.length < 1) {
                bool = false;
                filter_limit = results.length;
                filter_offset = results.length;
                return false
            } else { bool = true }
            
            res.render('filtersearch', { 
                title: 'Filter results', 
                results,
                nextFiterdisabled
            })
        })
    }
    else {
        res.render('wrongurl', {
            msg:'Generate A Filter Search First To Get The Proper Result',
            followingURLtext: 'Filte Search',
            followingURL: '/filter',
            elements: 'true',
            elements2: 'false',
        })
    }
})
app.get('/salary', (req, res) => {
    res.render( 'salary', { title: 'Provide salary' })
})
app.get('/employee', (req, res) => {
    res.render( 'employee', { title: 'Employee Details' })
})
app.get('/addemployee', (req, res) => {
    res.render( 'addemployee', {title: 'Add a new employee'})
})
app.get('/success', (req, res) => {
    let sql = `SELECT * FROM employee ORDER BY employee.id DESC LIMIT 1`;
    db.query(sql, (err, data) => {
        storeId.push(data[0].id);
        if(err) throw err;
        res.render( 'success', { 
            msgId: 'Empoyee ID', data
        })
    })
})
app.get('/salaryadded', (req, res) => {
    let sql = `SELECT memberid, employeeid FROM salary ORDER BY salary.memberid DESC LIMIT 1`;
    db.query(sql, (err, data) => {
        if(err) throw err;
        res.render( 'salaryadded', { 
            msg: data 
        })
    })
})
app.get('/addinfo', (req, res) => {
    res.render( 'addinfo', { title: 'Add Information' })
})
app.post('/savegroup', (req, res) => {
    addgroup = {
        employee_group: req.body.addemployee_group
    }
    let sql = `INSERT INTO em_group (employee_group) VALUES ('${addgroup.employee_group}')`;
    db.query(sql, (err, data) => {
        if(err) throw err;
    })
    res.render('Successful', {
        title: 'Successfully assigned a new group',
        addedData : addgroup.employee_group
    });
})
app.post('/savedivision', (req, res) => {
    adddivision = {
        division: req.body.adddivision
    }
    let sql = `INSERT INTO employee_division (division) VALUES ('${adddivision.division}')`;
    db.query(sql, (err, data) => {
        if(err) throw err;
    })
    res.render('Successful', {
        title: 'Successfully assigned a new division',
        addedData : adddivision.division
    });
})
app.post('/savedqualification', (req, res) => {
    addqualification = {
        qualification: req.body.addqualification
    }
    let sql = `INSERT INTO qualification (qualification) VALUES ('${addqualification.qualification}')`;
    db.query(sql, (err, data) => {
        if(err) throw err;
    })
    res.render('Successful', {
        title: 'Successfully assigned a new qualification',
        addedData : addqualification.qualification
    });
})
app.post('/savequality', (req, res) => {
    addquality = {
        quality: req.body.addquality
    }
    let sql = `INSERT INTO quality (quality) VALUES ('${addquality.quality}')`;
    db.query(sql, (err, data) => {
        if(err) throw err;
    })
    res.render('Successful', {
        title: 'Successfully assigned a new quality',
        addedData : addquality.quality
    });
})
app.post('/savedesignation', (req, res) => {
    adddesignation = {
        designation: req.body.adddesignation
    }
    let sql = `INSERT INTO designation (designation) VALUES ('${adddesignation.designation}')`;
    db.query(sql, (err, data) => {
        if(err) throw err;
    })
    res.render('Successful', {
        title: 'Successfully assigned a new designation',
        addedData : adddesignation.designation
    });
})
app.post('/savecomments', (req, res) => {
    addcomments = {
        addcomments: req.body.addcomments
    }
    let sql = `INSERT INTO comments (comments) VALUES ('${addcomments.addcomments}')`;
    db.query(sql, (err, data) => {
        if(err) throw err;
    })
    res.render('Successful', {
        title: 'Successfully assigned a new addcomment',
        addedData : addcomments.addcomments
    });
})
app.post('/newemployee', (req, res) => {
    
    newEmployee = {
        name: req.body.name,
        designation: req.body.designation,
        division: req.body.division,
        employee_group: req.body.employee_group,
        dob: req.body.dob,
        date_of_join: req.body.date_of_join,
        phone: req.body.phone,
        email: req.body.email,
        qualification: req.body.qualification,
        experience_year: req.body.experience_year,
        publications: req.body.publications,
        quality: req.body.quality,
        comments: req.body.comments
    }
    let sql = `INSERT INTO employee SET ?`;
    db.query(sql, newEmployee, (err, rows) => {
        if (err) throw err;
    })
    res.redirect('success')
});
app.post('/addsalary', (req, res) => {
    let startPoint, endPoint, midPoint, aitem, position;
    addSalary = {
        employeeid: req.body.employeeid,
        basic_salary: req.body.basic_salary,
        date_of_salary_payment: req.body.date_of_salary_payment,
        allowance: req.body.allowance,
        number_of_increments: req.body.number_of_increments,
        per_increment_amount: req.body.per_increment_amount,
        total_increments_amounts: req.body.number_of_increments * req.body.per_increment_amount,
        medical: req.body.medical,
        special_bonus: req.body.special_bonus,
        provident_fund: req.body.provident_fund,
        benevolent_fund: req.body.benevolent_fund,
        conveyance: req.body.conveyance,
        gas: req.body.gas,
        electricity: req.body.electricity,
        water: req.body.water,
        insurance: req.body.insurance,
        tel_fax_internet_bill: req.body.tel_fax_internet_bill,
        revenue: req.body.revenue,
        welfare: req.body.welfare,
        contribution: req.body.contribution,
        over_time_hrs: req.body.over_time_hrs,
        Per_hrs_pay_rate: req.body.Per_hrs_pay_rate,
        total_overtime_hrs_rate: req.body.over_time_hrs * req.body.Per_hrs_pay_rate
    }

    aitem = parseInt(addSalary.employeeid);
    startPoint = 0;
    endPoint = storeId.length;
    
    while(startPoint <= endPoint) {
        midPoint = Math.floor((startPoint + endPoint) / 2)
        if(storeId[midPoint] == aitem) {
            position = midPoint;
            break;
        }
        else if(storeId[midPoint] < aitem) {
            startPoint = midPoint + 1
        }
        else {
            endPoint = midPoint - 1
        }
    }

    if (position == undefined) { res.render('noidfound') }
    else {
        let sql = `INSERT INTO salary SET ?; UPDATE salary SET gross_salary = basic_salary + allowance + medical + special_bonus + total_overtime_hrs_rate + total_increments_amounts, net_salary = gross_salary - (provident_fund + benevolent_fund + insurance + conveyance + gas + electricity + water + tel_fax_internet_bill + revenue + welfare + contribution); SELECT memberid FROM salary ORDER BY memberid ASC LIMIT 1`;
        db.query(sql, addSalary, (err, data) => {
            if (err) throw err
            storeMemberid = data[2];
        })
        res.redirect('salaryadded');
    }
})
// Set static folder
app.use(express.static(path.join(__dirname, 'public')))
// REST API
app.use('/api/employee', require('./routes/api/employee'));
app.all('*', (req, res) => {
    res.status(404).render('404', {
        msg: 'Sorry, Something went wrong'
    });
});
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server runnig on port: ${PORT}`));

