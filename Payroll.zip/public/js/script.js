function getDivisionApi() {
    fetch('http://localhost:4000/api/employee/division')
    .then(res => res.json())
    .then(data => {
        let output = '';
        data.forEach(division => {
            output += `<option class="group">${division.division}</option>`;
            document.getElementById("division").innerHTML = output;
        })
    })
    .catch(err => console.log(err))
}
getDivisionApi()

function getGroupApi() {
    fetch('http://localhost:4000/api/employee/group')
    .then(res => res.json())
    .then(data => {
        let output = '';
        data.forEach(group => {
            output += `<option class="group">${group.employee_group}</option>`;
            document.getElementById("employee_group").innerHTML = output;
        });

    })
    .catch(err => console.log(err))
}
getGroupApi()

function getQualificationApi() {
    fetch('http://localhost:4000/api/employee/qualification')
    .then(res => res.json())
    .then(data => {
        let output = '';
        data.forEach(group => {
            output += `<option class="group">${group.qualification}</option>`;
            document.getElementById("qualification").innerHTML = output;
        });

    })
    .catch(err => console.log(err))
}
getQualificationApi()

function getQualityApi() {
    fetch('http://localhost:4000/api/employee/quality')
    .then(res => res.json())
    .then(data => {
        let output = '';
        data.forEach(group => {
            output += `<option class="group">${group.quality}</option>`;
            document.getElementById("quality").innerHTML = output;
        });

    })
    .catch(err => console.log(err))
}
getQualityApi()

function getDesignationApi() {
    fetch('http://localhost:4000/api/employee/designation')
    .then(res => res.json())
    .then(data => {
        let output = '';
        data.forEach(group => {
            output += `<option class="group">${group.designation}</option>`;
            document.getElementById("designation").innerHTML = output;
        });

    })
    .catch(err => console.log(err))
}
getDesignationApi()

function getMonthApi() {
    fetch('http://localhost:4000/api/employee/month')
    .then(res => res.json())
    .then(data => {
        let output = '';
        data.forEach(group => {
            output += `<option class="group">${group.month}</option>`;
            document.getElementById("specific_month").innerHTML = output;
        });

    })
    .catch(err => console.log(err))
}
getMonthApi()

function getYearApi() {
    fetch('http://localhost:4000/api/employee/year')
    .then(res => res.json())
    .then(data => {
        let output = '';
        data.forEach(group => {
            output += `<option class="group">${group.year}</option>`;
            document.getElementById("specific_year").innerHTML = output;
        });

    })
    .catch(err => console.log(err))
}
getYearApi()

function getCommentsApi() {
    fetch('http://localhost:4000/api/employee/comments')
    .then(res => res.json())
    .then(data => {
        let output = '';
        data.forEach(group => {
            output += `<option class="group">${group.comments}</option>`;
            document.getElementById("comments").innerHTML = output;
        });

    })
    .catch(err => console.log(err))
}
getCommentsApi()

$(document).ready(function() {
    $(".rows-tr").next().remove();
    const preCheck = (item, bool) => $(item).parent('.enabledisable').next('.checkedButton').prop("disabled", true); 
    const changeToggle = (aguy, selectorguy) => {
        $(aguy+":checkbox").change(function() {
            if($(this).is(':checked')) {  
                $(this).prop("checked", true);
                $(aguy).parent('.enabledisable').next('.checkedButton').prop("disabled", false);
            }
            else{
                $(this).parent('.enabledisable').next('.checkedButton').prop("disabled", true);
            }	 
        });
    }    
    
    $('.disabled-true').parent(".input-pagination-container").css('grid-template-columns', '3fr auto') 
    $('.disabled-true').remove()
    $(".showhidesearch-true").remove()
    $('.followingURL-true').remove()

    for(let i = 1; i < 40; i++) {
        preCheck("input[name='switch']")
        preCheck('input[name='+'switch' + i + ']')
        changeToggle("input[name='switch']")
        changeToggle('input[name='+'switch' + i + ']')
    }
    $("#myInput").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("tr#report-data-row").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
    $('#print-content').click(function(){
        $("#employee-info").printThis({
            debug: false,
            importCSS: true,
            importStyle: false,
            printContainer: true,
            loadCSS: "http://localhost:4000/css/style.css",
            pageTitle: "",
            removeInline: false,
            removeInlineSelector: "*",
            printDelay: 333,
            header: null,
            footer: null,
            base: false,
            formValues: true,
            canvas: false,
            doctypeString: 'Payment slip',
            removeScripts: false,
            copyTagClasses: false,
            beforePrintEvent: null,
            beforePrint: null,
            afterPrint: null
        });    
    })
})

