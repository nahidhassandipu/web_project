-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2019 at 01:23 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `payroll`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comments` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comments`) VALUES
('Clever and imaginative when confronted with obstacles'),
('Develops continuous improvement methods'),
('Establishes effective working relationships'),
('Holds employees accountable for their own results'),
('Displays a practical approach to solving problems');

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE `designation` (
  `designation` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`designation`) VALUES
('Software engineer'),
('UI/UX Designer'),
('Librarian'),
('Office Assistant'),
('Account executive'),
('Manager'),
('Trainer'),
('Security guard');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `designation` varchar(40) NOT NULL,
  `division` varchar(50) NOT NULL,
  `employee_group` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `date_of_join` date NOT NULL,
  `phone` varchar(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `experience_year` int(2) NOT NULL,
  `publications` varchar(30) NOT NULL,
  `quality` varchar(40) NOT NULL,
  `comments` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `designation`, `division`, `employee_group`, `dob`, `date_of_join`, `phone`, `email`, `qualification`, `experience_year`, `publications`, `quality`, `comments`) VALUES
(1, 'Abdullah rahman', 'Security guard', 'Security Division', 'B', '1995-01-07', '2019-01-01', '98745632150', 'Abdullah.fakemail@gmail.com', 'Diploma in Computer Science and Application (DCSA)', 3, 'IST', 'Readily adaptable', 'Displays a practical approach to solving problems'),
(2, 'Munna imran', 'Software engineer', 'Software development', 'A', '1994-07-02', '2018-01-01', '01236547891', 'munna.fakemail@gmail.com', 'Diploma in Computer Science and Application (DCSA)', 5, 'BOU', 'Strong work ethic', 'Clever and imaginative when confronted with obstacles'),
(3, 'Maksud mir', 'Software engineer', 'Software development', 'C', '1994-06-01', '2019-01-01', '01236547891', 'maksud.fakemail@gmail.com', 'Computer Science Engineering (CSE)', 4, 'DU', 'Professional', 'Develops continuous improvement methods'),
(4, 'Sofiq islam', 'Account executive', 'Account and finance', 'B', '1997-08-06', '2017-01-01', '01234567891', 'shofiq.fakemail@gmail.com', 'Master of Science (MS)', 8, 'DU', 'Communicates well', 'Establishes effective working relationships'),
(5, 'Jafor ahmed', 'Manager', 'Management', 'A', '1092-07-15', '2018-03-01', '01234567890', 'jafor.fakemail@gmai.com', 'Master of Science (MS)', 6, 'JU', 'Team player', 'Holds employees accountable for their own results'),
(6, 'Dipto saha', 'UI/UX Designer', 'Design and Art', 'C', '1089-03-28', '2017-02-01', '20314569875', 'dipto.fakemail@gmail.com', 'Higher Secondary Certificate (HSC)', 3, 'IST', 'Dependable', 'Develops continuous improvement methods'),
(7, 'Azgar ali', 'UI/UX Designer', 'Design and Art', 'B', '1090-02-18', '2018-03-01', '20314569877', 'azgar.fakemail@gmail.com', 'Secondary School Certificate (SSC)', 6, '', 'Professional', 'Clever and imaginative when confronted with obstacles'),
(8, 'Nishan sahan', 'Trainer', 'Training Division', 'A', '1990-07-11', '2016-01-01', '20314569879', 'nishan.fakemail@gmail.com', 'Master of Science (MS)', 4, 'BU', 'Professional', 'Establishes effective working relationships'),
(9, 'Zahidul hasan\r\n', 'Account executive', 'Account and finance', 'C', '2019-07-11', '2019-02-01', '20314569129', 'zahidul.fakemail@gmail.com', 'Computer Science Engineering (CSE)', 7, 'BOU', 'Energetic and enthusiastic', 'Clever and imaginative when confronted with obstacles'),
(10, 'Reja huq', 'Librarian', 'Management', 'B', '1990-07-08', '2017-01-01', '01314569129', 'reja.fakemail@gmail.com', 'Higher Secondary Certificate (HSC)', 5, '', 'Dependable', 'Holds employees accountable for their own results'),
(11, 'Ali akbar', 'Software engineer', 'Software development', 'A', '1992-06-03', '2018-05-01', '01234532815', 'ali.fakemail@gmail.com', 'Computer Science Engineering (CSE)', 7, 'IST', 'Professional', 'Clever and imaginative when confronted with obstacles'),
(12, 'Ali reja', 'Security guard', 'Security Division', 'C', '1991-02-13', '2018-07-01', '01234122815', 'alireja.fakemail@gmail.com', 'Secondary School Certificate (SSC)', 4, '', 'Energetic and enthusiastic', 'Establishes effective working relationships'),
(13, 'Hossain ahmad', 'Software engineer', 'Software development', 'B', '1992-03-01', '2019-05-01', '01234531215', 'hossain.fakemail@gmail.com', 'Computer Science Engineering (CSE)', 5, 'IST', 'Energetic and enthusiastic', 'Holds employees accountable for their own results'),
(14, 'Biplov dutta', 'UI/UX Designer', 'Design and Art', 'B', '1991-02-13', '2018-05-01', '02454122815', 'biplov.fakemail@gmail.com', 'Computer Science Engineering (CSE)', 5, 'IST', 'Dependable', 'Develops continuous improvement methods'),
(15, 'Ratul Rakshit', 'Office Assistant', 'Account and finance', 'C', '1988-01-13', '2019-01-01', '01234564215', 'ratul.fakemail@gmail.com', 'Higher Secondary Certificate (HSC)', 2, '', 'Team player', 'Displays a practical approach to solving problems'),
(16, 'Jhon Doe', 'Trainer', 'Training Division', 'B', '1996-01-13', '2017-02-01', '01232122815', 'jhon.fakemail@gmail.com', 'Higher Secondary Certificate (HSC)', 8, 'BOU', 'Readily adaptable', 'Displays a practical approach to solving problems'),
(17, 'Mahabub rahman', 'Office Assistant', 'Management', 'A', '1985-11-13', '2018-02-01', '02344122815', 'mahabub.fakemail@gmail.com', 'Higher Secondary Certificate (HSC)', 3, 'IST', 'Strong work ethic', 'Develops continuous improvement methods'),
(18, 'Maya aktar', 'UI/UX Designer', 'Design and Art', 'A', '1994-09-23', '2018-05-01', '01234132855', 'maya.fakemail@gmail.com', 'Diploma in Computer Science & Application (DCSA)', 3, 'IST', 'Dependable', 'Displays a practical approach to solving problems'),
(19, 'Emon safin', 'Software engineer', 'Software development', 'A', '1991-02-13', '2018-07-01', '01234122815', 'ridoy.fakemail@gmail.com', 'Computer Science Engineering (CSE)', 0, 'JU', 'Dependable', 'Clever and imaginative when confronted with obstacles'),
(20, 'Ridoy hassan', 'UI/UX Designer', 'Design and Art', 'B', '1989-02-24', '2019-02-01', '01231122815', 'ridoy.fakemail@gmail.com', 'Secondary School Certificate (SSC)', 1, 'DU', 'Strong work ethic', 'Develops continuous improvement methods'),
(21, 'Hassan molla', 'Librarian', 'Management', 'C', '1990-01-27', '2018-05-01', '01234122132', 'hassan.fakemail@gmail.com', 'Higher Secondary Certificate (HSC)', 2, 'BOU', 'Team player', 'Establishes effective working relationships'),
(22, 'Jhon soue', 'Office Assistant', 'Training Division', 'A', '1885-12-31', '2019-02-01', '02464122815', 'soue.fakemail@gmail.com', 'Secondary School Certificate (SSC)', 3, '', 'Communicates well', 'Holds employees accountable for their own result'),
(23, 'Mitro naim', 'Account executive', 'Account and finance', 'B', '1990-01-19', '2018-03-01', '01223522815', 'mitro.fakemail@gmail.com', 'Master of Science (MS)', 4, 'BU', 'Readily adaptable', 'Displays a practical approach to solving problems'),
(24, 'Al amin', 'Manager', 'Management', 'B', '1990-01-15', '2018-09-01', '01234124515', 'alamin.fakemail@gmail.com', 'Master of Science (MS)', 5, 'DU', 'Energetic and enthusiastic', 'Establishes effective working relationships'),
(25, 'Kamrul hassan', 'Security guard', 'Security Division', 'C', '1994-11-23', '2018-01-01', '03254122815', 'kamrul.fakemail@gmail.com', 'Secondary School Certificate (SSC)', 6, '', 'Professional', 'Clever and imaginative when confronted with obstacles'),
(26, 'Mamun roshid', 'Office Assistant', 'Management', 'A', '1986-01-11', '2018-01-01', '02144122815', 'mamun.fakemail@gmail.com', 'Higher Secondary Certificate (HSC)', 3, 'IST', 'Strong work ethic', 'Develops continuous improvement methods'),
(27, 'Jamya yeasmin', 'UI/UX Designer', 'Design and Art', 'A', '1987-02-12', '2018-02-01', '02234132855', 'jamya.fakemail@gmail.com', 'Diploma in Computer Science & Application (DCSA)', 3, 'IST', 'Dependable', 'Displays a practical approach to solving problems'),
(28, 'Musa kazim', 'Software engineer', 'Software development', 'A', '1988-03-13', '2018-03-01', '02334122815', 'musa.fakemail@gmail.com', 'Computer Science Engineering (CSE)', 0, 'JU', 'Dependable', 'Clever and imaginative when confronted with obstacles'),
(29, 'Baker hassan', 'UI/UX Designer', 'Design and Art', 'B', '1989-04-14', '2018-04-01', '02434122815', 'baker.fakemail@gmail.com', 'Secondary School Certificate (SSC)', 1, 'DU', 'Strong work ethic', 'Develops continuous improvement methods'),
(30, 'Mohammad hisham', 'Librarian', 'Management', 'C', '1990-05-15', '2018-05-01', '02534122815', 'hisham.fakemail@gmail.com', 'Higher Secondary Certificate (HSC)', 2, 'BOU', 'Team player', 'Establishes effective working relationships'),
(31, 'Arian khan', 'Office Assistant', 'Training Division', 'A', '1991-06-16', '2018-06-01', '02634122815', 'arian.fakemail@gmail.com', 'Secondary School Certificate (SSC)', 3, 'BU', 'Communicates well', 'Holds employees accountable for their own result'),
(32, 'Neel mahbub', 'Account executive', 'Account and finance', 'B', '1992-07-17', '2018-07-01', '02734122815', 'neel.fakemail@gmail.com', 'Master of Science (MS)', 4, 'DU', 'Readily adaptable', 'Displays a practical approach to solving problems'),
(33, 'Fahim hossain', 'Manager', 'Management', 'C', '1993-08-18', '2018-08-01', '02834122815', 'fahim.fakemail@gmail.com', 'Master of Science (MS)', 5, '', 'Energetic and enthusiastic', 'Establishes effective working relationships'),
(34, 'Raju ahmed', 'Security guard', 'Security Division', 'C', '1994-09-19', '2018-09-01', '02934122815', 'raju.fakemail@gmail.com', 'Secondary School Certificate (SSC)', 6, 'IST', 'Professional', 'Clever and imaginative when confronted with obstacles'),
(35, 'Samoa joe', 'Office Assistant', 'Management', 'A', '1986-12-21', '2018-08-01', '02144122825', 'samoa.fakemail@gmail.com', 'Higher Secondary Certificate (HSC)', 3, 'IST', 'Strong work ethic', 'Develops continuous improvement methods'),
(36, 'Foysal ahmed', 'UI/UX Designer', 'Design and Art', 'A', '1989-02-22', '2018-07-01', '02234132835', 'foysal.fakemail@gmail.com', 'Diploma in Computer Science & Application (DCSA)', 3, 'IST', 'Dependable', 'Displays a practical approach to solving problems'),
(37, 'Robi hassan', 'Software engineer', 'Software development', 'A', '1988-08-19', '2018-06-01', '02334122845', 'robi.fakemail@gmail.com', 'Computer Science Engineering (CSE)', 0, 'JU', 'Dependable', 'Clever and imaginative when confronted with obstacles'),
(38, 'Pankaj kumar', 'UI/UX Designer', 'Design and Art', 'B', '1990-01-24', '2018-05-01', '02434122855', 'pankaj.fakemail@gmail.com', 'Secondary School Certificate (SSC)', 1, 'DU', 'Strong work ethic', 'Develops continuous improvement methods'),
(39, 'Arafat khondokar', 'Librarian', 'Security Division', 'B', '1987-12-17', '2017-06-01', '01236547894', 'arafat.fakemail@gmial.com', 'Secondary School Certificate (SSC)', 2, '', 'Team player', 'Develops continuous improvement methods');

-- --------------------------------------------------------

--
-- Table structure for table `employee_division`
--

CREATE TABLE `employee_division` (
  `division` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_division`
--

INSERT INTO `employee_division` (`division`) VALUES
('Software development'),
('Design and Art'),
('Management'),
('Security Division'),
('Training Division'),
('Account and finance');

-- --------------------------------------------------------

--
-- Table structure for table `em_group`
--

CREATE TABLE `em_group` (
  `employee_group` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `em_group`
--

INSERT INTO `em_group` (`employee_group`) VALUES
('A'),
('B'),
('C');

-- --------------------------------------------------------

--
-- Table structure for table `month`
--

CREATE TABLE `month` (
  `month` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `month`
--

INSERT INTO `month` (`month`) VALUES
('January'),
('February'),
('March'),
('April'),
('May'),
('June'),
('July'),
('August'),
('September'),
('October'),
('November'),
('December');

-- --------------------------------------------------------

--
-- Table structure for table `qualification`
--

CREATE TABLE `qualification` (
  `qualification` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qualification`
--

INSERT INTO `qualification` (`qualification`) VALUES
('Computer Science Engineering (CSE)'),
('Secondary School Certificate (SSC)'),
('Higher Secondary Certificate (HSC)'),
('Diploma in Computer Science & Application (DCSA)'),
('Master of Science (MS)');

-- --------------------------------------------------------

--
-- Table structure for table `quality`
--

CREATE TABLE `quality` (
  `quality` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quality`
--

INSERT INTO `quality` (`quality`) VALUES
('Dependable'),
('Strong work ethic'),
('Team player'),
('Communicates well'),
('Readily adaptable'),
('Energetic and enthusiastic'),
('Professional');

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `memberid` int(11) NOT NULL,
  `employeeid` int(11) NOT NULL,
  `basic_salary` int(11) NOT NULL,
  `date_of_salary_payment` date NOT NULL,
  `number_of_increments` int(11) NOT NULL,
  `per_increment_amount` int(11) NOT NULL,
  `total_increments_amounts` int(11) NOT NULL,
  `allowance` int(11) NOT NULL,
  `medical` int(11) NOT NULL,
  `special_bonus` int(11) NOT NULL,
  `provident_fund` int(11) NOT NULL,
  `benevolent_fund` int(11) NOT NULL,
  `conveyance` int(11) NOT NULL,
  `gas` int(11) NOT NULL,
  `electricity` int(11) NOT NULL,
  `water` int(11) NOT NULL,
  `insurance` int(11) NOT NULL,
  `tel_fax_internet_bill` int(11) NOT NULL,
  `revenue` int(11) NOT NULL,
  `welfare` int(11) NOT NULL,
  `contribution` int(11) NOT NULL,
  `gross_salary` int(11) NOT NULL,
  `net_salary` int(11) NOT NULL,
  `over_time_hrs` int(11) NOT NULL,
  `Per_hrs_pay_rate` int(11) NOT NULL,
  `total_overtime_hrs_rate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`memberid`, `employeeid`, `basic_salary`, `date_of_salary_payment`, `number_of_increments`, `per_increment_amount`, `total_increments_amounts`, `allowance`, `medical`, `special_bonus`, `provident_fund`, `benevolent_fund`, `conveyance`, `gas`, `electricity`, `water`, `insurance`, `tel_fax_internet_bill`, `revenue`, `welfare`, `contribution`, `gross_salary`, `net_salary`, `over_time_hrs`, `Per_hrs_pay_rate`, `total_overtime_hrs_rate`) VALUES
(10, 2, 45000, '2018-02-01', 1, 2000, 2000, 300, 300, 400, 350, 450, 100, 300, 350, 250, 300, 550, 450, 200, 100, 48800, 45400, 4, 200, 800),
(11, 1, 7000, '2018-12-01', 1, 1000, 1000, 300, 300, 400, 350, 450, 100, 300, 350, 250, 300, 550, 450, 200, 100, 12800, 9400, 19, 200, 3800),
(12, 3, 45000, '2019-02-01', 0, 500, 0, 200, 320, 560, 550, 250, 120, 360, 320, 150, 120, 13, 550, 200, 100, 48080, 45347, 10, 200, 2000),
(13, 3, 45000, '2019-03-01', 0, 500, 0, 300, 370, 580, 590, 260, 125, 360, 325, 155, 125, 134, 555, 200, 400, 48850, 45621, 13, 200, 2600),
(14, 4, 35000, '2019-01-01', 3, 900, 2700, 390, 390, 590, 590, 290, 195, 390, 395, 125, 129, 139, 595, 290, 490, 43070, 39442, 20, 200, 4000),
(15, 8, 25000, '2016-03-01', 0, 1000, 0, 322, 322, 522, 522, 222, 122, 422, 332, 123, 125, 134, 515, 220, 410, 26466, 23319, 3, 100, 300),
(16, 8, 25000, '2016-02-01', 0, 1000, 0, 220, 120, 320, 320, 320, 325, 420, 325, 125, 325, 134, 515, 210, 420, 25960, 22521, 3, 100, 300),
(19, 11, 50000, '2017-02-01', 2, 1000, 2000, 210, 310, 510, 510, 210, 110, 310, 665, 443, 110, 11, 510, 410, 150, 57230, 53791, 21, 200, 4200),
(20, 11, 50000, '2017-05-01', 2, 1000, 2000, 320, 320, 520, 520, 220, 125, 420, 325, 125, 125, 134, 515, 210, 420, 53460, 50321, 3, 100, 300),
(31, 11, 50000, '2017-04-01', 2, 1000, 2000, 200, 320, 560, 550, 250, 120, 360, 320, 150, 120, 13, 550, 200, 100, 55080, 52347, 10, 200, 2000),
(32, 11, 50000, '2017-03-01', 2, 1000, 2000, 330, 330, 530, 530, 230, 135, 330, 335, 135, 135, 134, 535, 230, 430, 56390, 53231, 16, 200, 3200),
(46, 17, 15000, '2018-03-01', 0, 1000, 0, 310, 310, 510, 510, 210, 115, 410, 315, 115, 115, 114, 511, 211, 411, 16730, 13693, 6, 100, 600),
(47, 18, 30000, '2018-07-01', 1, 1000, 1000, 220, 120, 320, 320, 320, 325, 420, 325, 125, 325, 134, 515, 210, 420, 32020, 28581, 3, 120, 360),
(48, 18, 30000, '2018-06-01', 1, 1000, 1000, 422, 342, 422, 422, 202, 120, 420, 330, 133, 225, 234, 525, 223, 434, 32306, 29038, 1, 120, 120),
(49, 15, 15000, '2019-02-01', 0, 1000, 0, 322, 322, 522, 522, 222, 122, 422, 332, 123, 125, 134, 515, 220, 410, 16466, 13319, 3, 100, 300),
(50, 19, 45000, '2018-08-01', 1, 1000, 1000, 310, 310, 510, 510, 210, 115, 410, 325, 115, 215, 114, 514, 211, 411, 48810, 45660, 14, 120, 1680),
(51, 8, 25000, '2016-05-01', 0, 1000, 0, 320, 320, 520, 520, 220, 125, 320, 325, 125, 125, 134, 525, 220, 420, 26760, 23701, 3, 200, 600),
(80, 20, 30000, '2019-03-01', 0, 1000, 0, 310, 310, 510, 510, 210, 115, 410, 515, 95, 115, 114, 524, 211, 411, 33170, 29940, 17, 120, 2040),
(99, 2, 45000, '2018-03-01', 1, 2000, 2000, 320, 450, 400, 350, 450, 100, 300, 350, 250, 300, 550, 450, 200, 200, 50370, 46870, 11, 200, 2200),
(100, 18, 30000, '2018-09-01', 1, 1000, 1000, 310, 310, 510, 510, 210, 115, 410, 315, 115, 115, 114, 511, 211, 411, 32850, 29813, 6, 120, 720),
(101, 18, 30000, '2018-08-01', 1, 1000, 1000, 310, 310, 510, 510, 210, 115, 410, 315, 115, 115, 114, 511, 211, 411, 32850, 29813, 6, 120, 720),
(102, 8, 25000, '2016-04-01', 0, 1000, 0, 200, 320, 560, 550, 250, 120, 360, 320, 150, 120, 13, 550, 200, 100, 28080, 25347, 10, 200, 2000),
(103, 35, 15000, '2018-11-01', 1, 1000, 1000, 310, 310, 510, 510, 210, 115, 410, 315, 115, 115, 114, 511, 211, 411, 19230, 16193, 21, 100, 2100),
(104, 35, 15000, '2018-12-01', 1, 1000, 1000, 310, 310, 510, 510, 210, 115, 410, 315, 115, 115, 114, 511, 211, 411, 19130, 16093, 20, 100, 2000),
(105, 35, 15000, '2019-01-01', 1, 1000, 1000, 310, 310, 510, 510, 210, 115, 410, 315, 115, 115, 114, 511, 211, 411, 17930, 14893, 8, 100, 800),
(106, 35, 15000, '2019-02-01', 1, 1000, 1000, 310, 310, 510, 510, 210, 115, 410, 315, 115, 115, 114, 511, 211, 411, 18030, 14993, 9, 100, 900),
(107, 35, 15000, '2019-01-01', 1, 1000, 1000, 310, 310, 510, 510, 210, 115, 410, 315, 115, 115, 114, 511, 211, 411, 18830, 15793, 17, 100, 1700),
(108, 35, 15000, '2019-04-01', 1, 1000, 1000, 310, 310, 510, 510, 210, 115, 410, 315, 115, 115, 114, 511, 211, 411, 18130, 15093, 10, 100, 1000),
(109, 35, 15000, '2019-05-01', 1, 1000, 1000, 310, 310, 510, 510, 210, 115, 410, 315, 115, 115, 114, 511, 211, 411, 17830, 14793, 7, 100, 700),
(110, 35, 15000, '2019-06-01', 1, 1000, 1000, 310, 310, 510, 510, 210, 115, 410, 315, 115, 115, 114, 511, 211, 411, 17230, 14193, 1, 100, 100),
(111, 35, 15000, '2019-07-01', 1, 1000, 1000, 310, 310, 510, 510, 210, 115, 410, 315, 115, 115, 114, 511, 211, 411, 18230, 15193, 11, 100, 1100),
(112, 35, 15000, '2019-08-01', 1, 1000, 1000, 310, 310, 510, 510, 210, 115, 410, 315, 115, 115, 114, 511, 211, 411, 18330, 15293, 12, 100, 1200),
(113, 37, 45000, '2018-07-01', 1, 1000, 1000, 310, 310, 510, 510, 210, 115, 210, 214, 115, 115, 414, 111, 244, 4410, 47610, 40942, 4, 120, 480),
(114, 16, 25000, '2017-03-01', 2, 1000, 2000, 220, 120, 320, 320, 320, 325, 420, 325, 125, 325, 134, 515, 210, 420, 27960, 24521, 3, 100, 300),
(115, 2, 45000, '2018-04-01', 1, 2000, 2000, 500, 300, 400, 350, 450, 100, 300, 350, 350, 100, 450, 450, 200, 100, 48200, 45000, 0, 200, 0),
(116, 1, 7000, '2019-01-01', 1, 1000, 1000, 100, 200, 300, 450, 550, 90, 300, 350, 250, 300, 550, 450, 200, 100, 10800, 7210, 11, 200, 2200),
(117, 1, 7000, '2019-02-01', 1, 1000, 1000, 300, 300, 400, 350, 450, 100, 300, 350, 250, 300, 550, 450, 200, 100, 12200, 8800, 16, 200, 3200),
(118, 1, 7000, '2019-03-01', 1, 1000, 1000, 300, 300, 400, 350, 450, 100, 300, 350, 250, 300, 550, 450, 200, 100, 12800, 9400, 19, 200, 3800),
(119, 9, 35000, '2019-06-01', 0, 1000, 0, 420, 220, 528, 620, 225, 225, 320, 335, 155, 116, 156, 215, 110, 440, 38808, 35891, 22, 120, 2640),
(120, 5, 80000, '2019-07-01', 1, 1500, 1500, 500, 300, 350, 155, 250, 222, 100, 600, 200, 300, 200, 200, 500, 100, 85050, 82223, 6, 400, 2400),
(121, 12, 7000, '2019-07-01', 1, 1000, 1000, 500, 300, 350, 155, 250, 222, 100, 600, 200, 300, 200, 200, 500, 100, 11550, 8723, 6, 400, 2400),
(122, 39, 7000, '2019-02-01', 0, 1000, 0, 200, 300, 1000, 200, 100, 200, 400, 550, 210, 350, 100, 200, 300, 100, 10100, 7390, 20, 80, 1600),
(123, 21, 1000, '2018-10-01', 1, 1000, 1000, 600, 200, 1500, 200, 100, 150, 100, 500, 230, 450, 100, 200, 300, 100, 5650, 3220, 15, 90, 1350),
(124, 2, 45000, '2019-07-01', 1, 2000, 2000, 350, 400, 200, 300, 100, 500, 300, 500, 600, 100, 200, 500, 300, 600, 49950, 45950, 10, 200, 2000);

-- --------------------------------------------------------

--
-- Table structure for table `year`
--

CREATE TABLE `year` (
  `year` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `year`
--

INSERT INTO `year` (`year`) VALUES
('2017'),
('2019'),
('2018'),
('2018'),
('2019'),
('2017'),
('2018'),
('2019'),
('2018'),
('2019'),
('2017'),
('2018'),
('2019'),
('2017'),
('2018'),
('2019'),
('2018'),
('2019'),
('2017'),
('2018'),
('2019'),
('2018'),
('2019'),
('2017'),
('2018'),
('2019'),
('2018'),
('2019'),
('2017'),
('2018'),
('2019'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2017'),
('2016'),
('2018'),
('2019'),
('2016'),
('2018'),
('2019'),
('2016'),
('2018'),
('2019'),
('2016'),
('2018'),
('2019'),
('2016'),
('2018'),
('2019'),
('2016'),
('2018'),
('2019'),
('2016'),
('2018'),
('2019'),
('2016'),
('2018'),
('2019'),
('2016'),
('2018'),
('2019'),
('2016'),
('2018'),
('2019'),
('0'),
('2016'),
('2018'),
('2019'),
('2017'),
('0'),
('2016'),
('2018'),
('2019'),
('2017'),
('0'),
('2016'),
('2018'),
('2019'),
('2017'),
('0'),
('2016'),
('2018'),
('2019'),
('2017'),
('0'),
('2016'),
('2018'),
('2019'),
('2017'),
('0'),
('2018'),
('2019'),
('2017'),
('0'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017'),
('2018'),
('2019'),
('2016'),
('2017');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`memberid`),
  ADD KEY `employeeid` (`employeeid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `salary`
--
ALTER TABLE `salary`
  MODIFY `memberid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `salary`
--
ALTER TABLE `salary`
  ADD CONSTRAINT `salary_ibfk_1` FOREIGN KEY (`employeeid`) REFERENCES `employee` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
