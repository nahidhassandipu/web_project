const express = require('express');
const mysql = require('mysql');
const router = express.Router();
const db = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'dcsa'
});
db.connect((err) => {
    if (err) throw err;
});
// REST API for All
router.get('/', (req, res) => {
    let sql = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob FROM employee`;
    db.query(sql, (err, rows) => {
        if(err) throw err;
        res.json(rows);
    })
})
router.get('/division', (req, res) => {
    let sql = `SELECT division FROM employee_division`;
    db.query(sql, (err, rows) => {
        if(err) throw err;
        res.json(rows);
    })
})
router.get('/group', (req, res) => {
    let sql = `SELECT employee_group FROM em_group`;
    db.query(sql, (err, rows) => {
        if(err) throw err;
        res.json(rows);
    })
})
router.get('/qualification', (req, res) => {
    let sql = `SELECT qualification FROM qualification`;
    db.query(sql, (err, rows) => {
        if(err) throw err;
        res.json(rows);
    })
})
router.get('/quality', (req, res) => {
    let sql = `SELECT quality FROM quality`;
    db.query(sql, (err, rows) => {
        if(err) throw err;
        res.json(rows);
    })
})
router.get('/designation', (req, res) => {
    let sql = `SELECT designation FROM designation`;
    db.query(sql, (err, rows) => {
        if(err) throw err;
        res.json(rows);
    })
})
router.get('/comments', (req, res) => {
    let sql = `SELECT comments FROM comments`;
    db.query(sql, (err, rows) => {
        if(err) throw err;
        res.json(rows);
    })
})
router.get('/month', (req, res) => {
    let sql = `SELECT month FROM month`;
    db.query(sql, (err, rows) => {
        if(err) throw err;
        res.json(rows);
    })
})
router.get('/year', (req, res) => {
    let sql = `SELECT DISTINCT year FROM year where year !='0'`;
    db.query(sql, (err, rows) => {
        if(err) throw err;
        res.json(rows);
    })
})
// REST API for Single id 
router.get('/:id', (req, res) => {
    let sql = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob FROM employee`;
    db.query(sql, (err, rows) => {
        const checkId = row => row.id === parseInt(req.params.id);
        const found = rows.some(checkId);
        if(err) throw err;
        if (found) { res.json(rows.filter(checkId)) } 
        else { res.status(400).json({ msg : `No member with the id of ${req.params.id}` }) }
    })
});
module.exports = router;