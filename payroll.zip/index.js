const express = require('express');
const path = require('path');
const exphbs = require('express-handlebars');
const mysql = require('mysql');
const app = express();
const db = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'dcsa',
    multipleStatements: true
});
db.connect((err) => {
    if (err) throw err;
    console.log('Database connected...')
});
app.engine('handlebars', exphbs({
    defaultLayout: 'main',
    layoutsDir: __dirname + '/views/layouts/',
    partialsDir: __dirname + '/views/partials/'
}));
app.set('view engine', 'handlebars');
// Handlebars.registerPartial('content', '{{name}}')
// Body parser middleware
app.use(express.json());
app.use(express.urlencoded({extended: false}));
function checkResNumValue(requestData, defaultVal) {
    if( typeof(requestData) == 'undefined' ) { 
        return defaultVal
    } else { 
        return requestData;
    }
}

// Limit set for employeesalary page 
employee_salary_limit = 10;
employee_salary_offset = 10;

// Limit set for allsalary page 
allsalary_limit = 10;
allsalary_offset = 10;

// Limit set for allemployee page 
allemployee_limit = 10;
allemployee_offset = 10;

// Store sql filter query 
storeResult = undefined;
// Limit set for filter page 
filter_limit = 10;
filter_offset = 10;

// Store sql search query 
searchResult = undefined;
getID = undefined;
// Limit set for search page 
search_limit = 10;
search_offset = 10;

app.get('/employeesalary_prev', (req, res) => {
    
    if (employee_salary_limit <= 10 ) {
        employee_salary_limit = 0;
        employee_salary_offset = 10;
    } else { employee_salary_limit -= 10; }

    let sql = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join, DATE_FORMAT(date_of_salary_payment, '%D %M %Y') AS date_of_salary_payment FROM employee INNER JOIN salary ON employee.id = salary.employeeid ORDER BY memberid DESC LIMIT ${employee_salary_limit}, ${employee_salary_offset}`;

    db.query(sql, (err, rows) => {
        if(err) throw err;
        res.render('employeesalary', { 
            title: 'Details of employees with salaries',
            rows 
        })
    })
})
app.get('/employeesalary_next', (req, res) => {
    
    let bool = true;
    if (bool == true) { employee_salary_limit += 10 } 
    
    let sql = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join, DATE_FORMAT(date_of_salary_payment, '%D %M %Y') AS date_of_salary_payment FROM employee INNER JOIN salary ON employee.id = salary.employeeid ORDER BY memberid DESC LIMIT ${employee_salary_limit}, ${employee_salary_offset}`;

    db.query(sql, (err, rows) => {
        if(err) throw err;
        if (rows.length < 1) {
            bool = false;
            employee_salary_limit = rows.length;
            employee_salary_offset = rows.length;
            return false
        } else { bool = true }
        res.render('employeesalary', { 
            title: 'Details of employees with salaries',
            rows
        })
    })
})

app.get('/allsalary_prev', (req, res) => {
    
    if (allsalary_limit <= 10 ) {
        allsalary_limit = 0;
        allsalary_offset = 10;
    } else { allsalary_limit -= 10; }

    let sql = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join, DATE_FORMAT(date_of_salary_payment, '%D %M %Y') AS date_of_salary_payment FROM employee INNER JOIN salary ON employee.id = salary.employeeid ORDER BY memberid DESC LIMIT ${allsalary_limit}, ${allsalary_offset}`;

    db.query(sql, (err, rows) => {
        if(err) throw err;
        res.render('allsalary', { 
            title: 'Details of salaries',
            rows 
        })
    })
})
app.get('/allsalary_next', (req, res) => {
    
    let bool = true;
    if (bool == true) { allsalary_limit += 10 } 
    
    let sql = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join, DATE_FORMAT(date_of_salary_payment, '%D %M %Y') AS date_of_salary_payment FROM employee INNER JOIN salary ON employee.id = salary.employeeid ORDER BY memberid DESC LIMIT ${allsalary_limit}, ${allsalary_offset}`;

    db.query(sql, (err, rows) => {
        if(err) throw err;
        if (rows.length < 1) {
            bool = false;
            allsalary_limit = rows.length;
            allsalary_offset = rows.length;
            return false
        } else { bool = true }
        res.render('allsalary', { 
            title: 'Details of salaries',
            rows 
        })
    })
})

app.get('/allemployees_prev', (req, res) => {
    
    if (allemployee_limit <= 10 ) {
        allemployee_limit = 0;
        allemployee_offset = 10;
    } else { allemployee_limit -= 10; }

    let sql = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join FROM employee ORDER BY id LIMIT ${allemployee_limit}, ${allemployee_offset}`;

    db.query(sql, (err, rows) => {
        if(err) throw err;
        res.render('allemployee', { 
            title: 'Details of employees', 
            rows 
        })
    })
})
app.get('/allemployees_next', (req, res) => {
    
    let bool = true;
    if (bool == true) { allemployee_limit += 10 } 
    
    let sql = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join FROM employee ORDER BY id LIMIT ${allemployee_limit}, ${allemployee_offset}`;

    db.query(sql, (err, rows) => {
        if(err) throw err;
        if (rows.length < 1) {
            bool = false;
            allemployee_limit = rows.length;
            allemployee_offset = rows.length;
            return false
        } else { bool = true }
        res.render('allemployee', { 
            title: 'Details of employees', 
            rows 
        })
    })
})

app.get('/filter_prev', (req, res) => {
    
    if (filter_limit <= 10 ) {
        filter_limit = 0;
        filter_offset = 10;
    } else { filter_limit -= 10; }
    
    let sql = `${storeResult} LIMIT ${filter_limit}, ${filter_offset}`;

    db.query(sql, (err, results) => {
        if(err) throw err;
        res.render('filtersearch', { 
            title: 'Filter results', 
            results 
        })
    })
})
app.get('/filter_next', (req, res) => {
    
    let bool = true;
    if (bool == true) { filter_limit += 10 } 
    
    let sql = `${storeResult} LIMIT ${filter_limit}, ${filter_offset}`;

    db.query(sql, (err, results) => {
        if(err) throw err;
        if (results.length < 1) {
            bool = false;
            filter_limit = results.length;
            filter_offset = results.length;
            return false
        } else { bool = true }
        res.render('filtersearch', { 
            title: 'Filter results', 
            results 
        })
    })
})

app.get('/search_prev', (req, res) => {
    
    if (search_limit <= 10 ) {
        search_limit = 0;
        search_offset = 10;
    } else { search_limit -= 10; }
    
    let sql = `${searchResult} LIMIT ${search_limit}, ${search_offset}`;

    db.query(sql, (err, rows) => {
        if(err) throw err;
        res.render('search', { 
            title: `Details employee ID - ${getID}`, 
            rows 
        })
    })
})
app.get('/search_next', (req, res) => {
    
    let bool = true;
    if (bool == true) { search_limit += 10 } 
    
    let sql = `${searchResult} LIMIT ${search_limit}, ${search_offset}`;

    db.query(sql, (err, rows) => {
        if(err) throw err;
        if (rows.length < 1) {
            bool = false;
            search_limit = rows.length;
            search_offset = rows.length;
            return false
        } else { bool = true }
        res.render('search', { 
            title: `Details employee ID - ${getID}`, 
            rows 
        })
    })
})

app.get('/', (req, res) => {
    res.render('home', { title: 'Welcome to home page' })
})
app.get('/allemployee', (req, res) => {
    allemployee_limit = 0;
    allemployee_offset = 10;
    let sql = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join FROM employee ORDER BY id LIMIT 10;`;
    db.query(sql, (err, rows) => {
        if(err) throw err;
        res.render('allemployee', { 
            title: 'Details of employees', 
            rows 
        })
    })
});
app.get('/allsalary', (req, res) => {
    allsalary_limit = 0;
    allsalary_offset = 10;
    let sql = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join, DATE_FORMAT(date_of_salary_payment, '%D %M %Y') AS date_of_salary_payment FROM employee INNER JOIN salary ON employee.id = salary.employeeid ORDER BY memberid DESC LIMIT 10`;
    db.query(sql, (err, rows) => {
        if(err) throw err;
        res.render('allsalary', { 
            title: 'Details of salaries',
            rows 
        })
    })
});
app.get('/employeesalary', (req, res) => {
    employee_salary_limit = 0;
    employee_salary_offset = 10;
    let sql = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join, DATE_FORMAT(date_of_salary_payment, '%D %M %Y') AS date_of_salary_payment FROM employee INNER JOIN salary ON employee.id = salary.employeeid ORDER BY memberid DESC LIMIT 10`;
    db.query(sql, (err, rows) => {
        if(err) throw err;
        res.render('employeesalary', { 
            title: 'Details of employees with salaries', 
            rows 
        })
    })
});

app.get('/search', (req, res) => {
    
    search_limit = 0;
    search_offset = 10;

    let sql = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join, DATE_FORMAT(date_of_salary_payment, '%D %M %Y') AS date_of_salary_payment FROM employee INNER JOIN salary ON employee.id = salary.employeeid ORDER BY memberid DESC`;

    db.query(sql, (err, rows) => {
        const qst = {id: req.query.id}
        const checkId = row => row.id === parseInt(qst.id);
        const found = rows.some(checkId);
        
        if(err) throw err;
        if (found) { 
            res.render( 'search', { 
                title: `Details employee ID - ${qst.id}`,
                rows: rows.filter(checkId)
            })
            let searchQuery = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join, DATE_FORMAT(date_of_salary_payment, '%D %M %Y') AS date_of_salary_payment FROM employee INNER JOIN salary ON employee.id = salary.employeeid WHERE employee.id = ${qst.id} ORDER BY memberid DESC`;
            searchResult = searchQuery;
            getID = qst.id;
        }
        else { res.render( 'notexist', { msg : `${qst.id}` }) }
    })
});
app.get('/employeeid', (req, res) => {
    filterEmployee = {
        id: checkResNumValue(req.query.id, 'employee.id'),
        date_of_salary_payment: checkResNumValue(req.query.date_of_salary_payment, 'salary.date_of_salary_payment')
    }
    let sql = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join, DATE_FORMAT(date_of_salary_payment, '%D %M %Y') AS date_of_salary_payment FROM employee INNER JOIN salary ON employee.id = salary.employeeid WHERE employee.id = ${filterEmployee.id} AND salary.date_of_salary_payment = ${filterEmployee.date_of_salary_payment != 'salary.date_of_salary_payment' ? "'" + filterEmployee.date_of_salary_payment + "'" : filterEmployee.date_of_salary_payment } ORDER BY memberid DESC LIMIT 1`
    db.query(sql, (err, results) => {
        if(err) {
            res.render( '404', { msg : `Nothig Really found` })
        } 
        else {
            res.render( 'employeeid', { 
                title: 'Employee details',
                results
            })
        }
    })
});
app.get('/filtersearch', (req, res) => { 
    filter_limit = 0;
    filter_offset = 10;
    filterItem = {
        memberid: checkResNumValue(req.query.memberid, 'salary.memberid'),
        id: checkResNumValue(req.query.id, 'employee.id'),
        name: checkResNumValue(req.query.name, 'employee.name'),
        designation: checkResNumValue(req.query.designation, 'employee.designation'),
        employee_group: checkResNumValue(req.query.employee_group, 'employee.employee_group'),
        division : checkResNumValue(req.query.division, 'employee.division'),
        phone: checkResNumValue(req.query.phone, 'employee.phone'),
        email: checkResNumValue(req.query.email, 'employee.email'),
        dob: checkResNumValue(req.query.dob, 'employee.dob'),
        date_of_salary_payment: checkResNumValue(req.query.date_of_salary_payment, 'salary.date_of_salary_payment'),
        specific_month: checkResNumValue(req.query.specific_month, 'MONTHNAME(salary.date_of_salary_payment)'),
        specific_year: checkResNumValue(req.query.specific_year, 'YEAR(salary.date_of_salary_payment)'),
        date_of_join: checkResNumValue(req.query.date_of_join, 'employee.date_of_join'),
        qualification: checkResNumValue(req.query.qualification, 'employee.qualification'),
        experience_year: checkResNumValue(req.query.experience_year, 'employee.experience_year'),
        quality: checkResNumValue(req.query.quality, 'employee.quality'),
        basic_salary: checkResNumValue(req.query.basic_salary, `salary.basic_salary`),
        gross_salary: checkResNumValue(req.query.gross_salary, `salary.gross_salary`),
        net_salary: checkResNumValue(req.query.net_salary, `salary.net_salary`),
        number_of_increments: checkResNumValue(req.query.number_of_increments, `salary.number_of_increments`),
        per_increment_amount: checkResNumValue(req.query.per_increment_amount, `salary.per_increment_amount`),
        total_increments_amounts: checkResNumValue(req.query.total_increments_amounts, `salary.total_increments_amounts`),
        allowance: checkResNumValue(req.query.allowance, `salary.allowance`),
        medical: checkResNumValue(req.query.medical, `salary.medical`),
        special_bonus: checkResNumValue(req.query.special_bonus, `salary.special_bonus`),
        provident_fund: checkResNumValue(req.query.provident_fund, `salary.provident_fund`),
        benevolent_fund: checkResNumValue(req.query.benevolent_fund, `salary.benevolent_fund`),
        conveyance: checkResNumValue(req.query.conveyance, `salary.conveyance`),
        gas: checkResNumValue(req.query.gas, `salary.gas`),
        electricity: checkResNumValue(req.query.electricity, `salary.electricity`),
        water: checkResNumValue(req.query.water, `salary.water`),
        insurance: checkResNumValue(req.query.insurance, `salary.insurance`),
        tel_fax_internet_bill: checkResNumValue(req.query.tel_fax_internet_bill, `salary.tel_fax_internet_bill`),
        revenue: checkResNumValue(req.query.revenue, `salary.revenue`),
        welfare: checkResNumValue(req.query.welfare, `salary.welfare`),
        contribution: checkResNumValue(req.query.contribution, `salary.contribution`),
        over_time_hrs: checkResNumValue(req.query.over_time_hrs, `salary.over_time_hrs`),
        Per_hrs_pay_rate: checkResNumValue(req.query.Per_hrs_pay_rate, `salary.Per_hrs_pay_rate`),
        total_overtime_hrs_rate: checkResNumValue(req.query.total_overtime_hrs_rate, `salary.total_overtime_hrs_rate`)
    }
    let sql = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join, DATE_FORMAT(date_of_salary_payment, '%D %M %Y') AS date_of_salary_payment FROM employee INNER JOIN salary ON employee.id = salary.employeeid WHERE salary.memberid = ${filterItem.memberid} AND employee.id = ${filterItem.id} AND employee.name = ${filterItem.name != 'employee.name' ? "'" + filterItem.name + "'" : filterItem.name } AND employee.employee_group = ${filterItem.employee_group != 'employee.employee_group' ? "'" + filterItem.employee_group + "'" : filterItem.employee_group } AND employee.division = ${filterItem.division != 'employee.division' ? "'" + filterItem.division + "'" : filterItem.division} AND employee.designation = ${filterItem.designation != 'employee.designation' ? "'" + filterItem.designation + "'" : filterItem.designation } AND employee.phone = ${filterItem.phone != 'employee.phone' ? "'" + filterItem.phone + "'" : filterItem.phone } AND employee.email = ${filterItem.email != 'employee.email' ? "'" + filterItem.email + "'" : filterItem.email } AND employee.qualification = ${filterItem.qualification != 'employee.qualification' ? "'" + filterItem.qualification + "'" : filterItem.qualification } AND employee.experience_year = ${filterItem.experience_year != 'employee.experience_year' ? "'" + filterItem.experience_year + "'" : filterItem.experience_year } AND employee.quality = ${filterItem.quality != 'employee.quality' ? "'" + filterItem.quality + "'" : filterItem.quality } AND employee.dob = ${filterItem.dob != 'employee.dob' ? "'" + filterItem.dob + "'" : filterItem.dob } AND employee.date_of_join = ${filterItem.date_of_join != 'employee.date_of_join' ? "'" + filterItem.date_of_join + "'" : filterItem.date_of_join } AND salary.date_of_salary_payment = ${filterItem.date_of_salary_payment != 'salary.date_of_salary_payment' ? "'" + filterItem.date_of_salary_payment + "'" : filterItem.date_of_salary_payment } AND MONTHNAME(salary.date_of_salary_payment) = ${filterItem.specific_month != 'MONTHNAME(salary.date_of_salary_payment)' ? "'" + filterItem.specific_month + "'" : 'MONTHNAME(salary.date_of_salary_payment)'} AND YEAR(salary.date_of_salary_payment) = ${filterItem.specific_year != 'YEAR(salary.date_of_salary_payment)' ? "'" + filterItem.specific_year + "'" : 'YEAR(salary.date_of_salary_payment)'} AND salary.basic_salary = ${filterItem.basic_salary} AND salary.number_of_increments = ${filterItem.number_of_increments} AND salary.per_increment_amount = ${filterItem.per_increment_amount} AND salary.total_increments_amounts = ${filterItem.total_increments_amounts} AND salary.allowance = ${filterItem.allowance} AND salary.medical = ${filterItem.medical} AND salary.special_bonus = ${filterItem.special_bonus} AND salary.provident_fund = ${filterItem.provident_fund} AND salary.benevolent_fund = ${filterItem.benevolent_fund} AND salary.conveyance = ${filterItem.conveyance} AND salary.gas = ${filterItem.gas} AND salary.electricity = ${filterItem.electricity} AND salary.water = ${filterItem.water} AND salary.insurance = ${filterItem.insurance} AND salary.tel_fax_internet_bill = ${filterItem.tel_fax_internet_bill} AND salary.revenue = ${filterItem.revenue} AND salary.welfare = ${filterItem.welfare} AND salary.contribution = ${filterItem.contribution} AND salary.gross_salary = ${filterItem.gross_salary} AND salary.net_salary = ${filterItem.net_salary} AND salary.over_time_hrs = ${filterItem.over_time_hrs} AND salary.Per_hrs_pay_rate = ${filterItem.Per_hrs_pay_rate} AND salary.total_overtime_hrs_rate = ${filterItem.total_overtime_hrs_rate} ORDER BY memberid DESC LIMIT 10`
    
    let sqlLimitless = `SELECT *, DATE_FORMAT(dob, '%D %M %Y') AS dob, DATE_FORMAT(date_of_join, '%D %M %Y') AS date_of_join, DATE_FORMAT(date_of_salary_payment, '%D %M %Y') AS date_of_salary_payment FROM employee INNER JOIN salary ON employee.id = salary.employeeid WHERE salary.memberid = ${filterItem.memberid} AND employee.id = ${filterItem.id} AND employee.name = ${filterItem.name != 'employee.name' ? "'" + filterItem.name + "'" : filterItem.name } AND employee.employee_group = ${filterItem.employee_group != 'employee.employee_group' ? "'" + filterItem.employee_group + "'" : filterItem.employee_group } AND employee.division = ${filterItem.division != 'employee.division' ? "'" + filterItem.division + "'" : filterItem.division} AND employee.designation = ${filterItem.designation != 'employee.designation' ? "'" + filterItem.designation + "'" : filterItem.designation } AND employee.phone = ${filterItem.phone != 'employee.phone' ? "'" + filterItem.phone + "'" : filterItem.phone } AND employee.email = ${filterItem.email != 'employee.email' ? "'" + filterItem.email + "'" : filterItem.email } AND employee.qualification = ${filterItem.qualification != 'employee.qualification' ? "'" + filterItem.qualification + "'" : filterItem.qualification } AND employee.experience_year = ${filterItem.experience_year != 'employee.experience_year' ? "'" + filterItem.experience_year + "'" : filterItem.experience_year } AND employee.quality = ${filterItem.quality != 'employee.quality' ? "'" + filterItem.quality + "'" : filterItem.quality } AND employee.dob = ${filterItem.dob != 'employee.dob' ? "'" + filterItem.dob + "'" : filterItem.dob } AND employee.date_of_join = ${filterItem.date_of_join != 'employee.date_of_join' ? "'" + filterItem.date_of_join + "'" : filterItem.date_of_join } AND salary.date_of_salary_payment = ${filterItem.date_of_salary_payment != 'salary.date_of_salary_payment' ? "'" + filterItem.date_of_salary_payment + "'" : filterItem.date_of_salary_payment } AND MONTHNAME(salary.date_of_salary_payment) = ${filterItem.specific_month != 'MONTHNAME(salary.date_of_salary_payment)' ? "'" + filterItem.specific_month + "'" : 'MONTHNAME(salary.date_of_salary_payment)'} AND YEAR(salary.date_of_salary_payment) = ${filterItem.specific_year != 'YEAR(salary.date_of_salary_payment)' ? "'" + filterItem.specific_year + "'" : 'YEAR(salary.date_of_salary_payment)'} AND salary.basic_salary = ${filterItem.basic_salary} AND salary.number_of_increments = ${filterItem.number_of_increments} AND salary.per_increment_amount = ${filterItem.per_increment_amount} AND salary.total_increments_amounts = ${filterItem.total_increments_amounts} AND salary.allowance = ${filterItem.allowance} AND salary.medical = ${filterItem.medical} AND salary.special_bonus = ${filterItem.special_bonus} AND salary.provident_fund = ${filterItem.provident_fund} AND salary.benevolent_fund = ${filterItem.benevolent_fund} AND salary.conveyance = ${filterItem.conveyance} AND salary.gas = ${filterItem.gas} AND salary.electricity = ${filterItem.electricity} AND salary.water = ${filterItem.water} AND salary.insurance = ${filterItem.insurance} AND salary.tel_fax_internet_bill = ${filterItem.tel_fax_internet_bill} AND salary.revenue = ${filterItem.revenue} AND salary.welfare = ${filterItem.welfare} AND salary.contribution = ${filterItem.contribution} AND salary.gross_salary = ${filterItem.gross_salary} AND salary.net_salary = ${filterItem.net_salary} AND salary.over_time_hrs = ${filterItem.over_time_hrs} AND salary.Per_hrs_pay_rate = ${filterItem.Per_hrs_pay_rate} AND salary.total_overtime_hrs_rate = ${filterItem.total_overtime_hrs_rate} ORDER BY memberid DESC`
    
    db.query(sql, (err, results) => {
        if(err) {
            res.render( '404', { msg : `Nothig Really found` })
        } 
        else {
            res.render( 'filtersearch', { 
                title: `Filter results`,
                results
            })
            storeResult = sqlLimitless;
        }
    })
});
app.get('/filter', (req, res) => { 
    let sql = `DELETE year FROM year; INSERT INTO year(year) SELECT DISTINCT YEAR(salary.date_of_salary_payment) FROM salary ORDER BY YEAR(salary.date_of_salary_payment)`;
    db.query(sql, (err, groups) => {
        if(err) throw err;
        res.render( 'filter', { 
            title: 'Make a filter search',
        })
    })
})
app.get('/salary', (req, res) => {
    res.render( 'salary', { title: 'Provide salary' })
})
app.get('/notexist', (req, res) => {
    res.render( 'notexist' )
})
app.get('/employee', (req, res) => {
    res.render( 'employee', { title: 'Employee Details' })
})
app.get('/addemployee', (req, res) => {
    res.render( 'addemployee', {title: 'Add a new employee'})
})
app.get('/success', (req, res) => {
    let sql = `SELECT * FROM employee ORDER BY employee.id DESC LIMIT 1`;
    db.query(sql, (err, data) => {
        if(err) throw err;
        res.render( 'success', { 
            msgId: 'Empoyee ID', data 
        })
    })
})
app.get('/successful', (req, res) => {
    res.render( 'successful', {title: 'Successful'})
})
app.get('/salaryadded', (req, res) => {
    let sql = `SELECT * FROM salary ORDER BY salary.memberid DESC LIMIT 1`;
    db.query(sql, (err, data) => {
        if(err) throw err;
        res.render( 'salaryadded', { 
            msg: data 
        })
    })
})
app.get('/customize', (req, res) => {
    res.render( 'customize', { title: 'Add Information' })
})
app.post('/savegroup', (req, res) => {
    addgroup = {
        employee_group: req.body.addemployee_group
    }
    let sql = `INSERT INTO em_group (employee_group) VALUES ('${addgroup.employee_group}')`;
    db.query(sql, (err, data) => {
        if(err) throw err;
    })
    res.redirect('Successful');
})
app.post('/savedivision', (req, res) => {
    adddivision = {
        division: req.body.adddivision
    }
    let sql = `INSERT INTO employee_division (division) VALUES ('${adddivision.division}')`;
    db.query(sql, (err, data) => {
        if(err) throw err;
    })
    res.redirect('Successful');
})
app.post('/savedqualification', (req, res) => {
    addqualification = {
        qualification: req.body.addqualification
    }
    let sql = `INSERT INTO qualification (qualification) VALUES ('${addqualification.qualification}')`;
    db.query(sql, (err, data) => {
        if(err) throw err;
    })
    res.redirect('Successful');
})
app.post('/savequality', (req, res) => {
    addquality = {
        quality: req.body.addquality
    }
    let sql = `INSERT INTO quality (quality) VALUES ('${addquality.quality}')`;
    db.query(sql, (err, data) => {
        if(err) throw err;
    })
    res.redirect('Successful');
})
app.post('/savedesignation', (req, res) => {
    adddesignation = {
        designation: req.body.adddesignation
    }
    let sql = `INSERT INTO designation (designation) VALUES ('${adddesignation.designation}')`;
    db.query(sql, (err, data) => {
        if(err) throw err;
    })
    res.redirect('Successful');
})
app.post('/savecomments', (req, res) => {
    addcomments = {
        addcomments: req.body.addcomments
    }
    let sql = `INSERT INTO comments (comments) VALUES ('${addcomments.addcomments}')`;
    db.query(sql, (err, data) => {
        if(err) throw err;
    })
    res.redirect('Successful');
})
// Create employee
app.post('/newemployee', (req, res) => {
    newEmployee = {
        name: req.body.name,
        designation: req.body.designation,
        division: req.body.division,
        employee_group: req.body.employee_group,
        dob: req.body.dob,
        date_of_join: req.body.date_of_join,
        phone: req.body.phone,
        email: req.body.email,
        qualification: req.body.qualification,
        experience_year: req.body.experience_year,
        publications: req.body.publications,
        quality: req.body.quality,
        comments: req.body.comments
    }
    let sql = `INSERT INTO employee SET ?`;
    db.query(sql, newEmployee, (err, rows) => {
        if (err) throw err;
    })
    res.redirect('success')
});
// res.render('success', {msg: `Submitted ID - ${newEmployee.id}`})
// Add salary 
app.post('/addsalary', (req, res) => {
    addSalary = {
        employeeid: req.body.employeeid,
        basic_salary: req.body.basic_salary,
        date_of_salary_payment: req.body.date_of_salary_payment,
        allowance: req.body.allowance,
        number_of_increments: req.body.number_of_increments,
        per_increment_amount: req.body.per_increment_amount,
        total_increments_amounts: req.body.number_of_increments * req.body.per_increment_amount,
        medical: req.body.medical,
        special_bonus: req.body.special_bonus,
        provident_fund: req.body.provident_fund,
        benevolent_fund: req.body.benevolent_fund,
        conveyance: req.body.conveyance,
        gas: req.body.gas,
        electricity: req.body.electricity,
        water: req.body.water,
        insurance: req.body.insurance,
        tel_fax_internet_bill: req.body.tel_fax_internet_bill,
        revenue: req.body.revenue,
        welfare: req.body.welfare,
        contribution: req.body.contribution,
        over_time_hrs: req.body.over_time_hrs,
        Per_hrs_pay_rate: req.body.Per_hrs_pay_rate,
        total_overtime_hrs_rate: req.body.over_time_hrs * req.body.Per_hrs_pay_rate
    }
    let sql = `INSERT INTO salary SET ?; UPDATE salary SET gross_salary = basic_salary + allowance + medical + special_bonus + total_overtime_hrs_rate + total_increments_amounts, net_salary = gross_salary - (provident_fund + benevolent_fund + insurance + conveyance + gas + electricity + water + tel_fax_internet_bill + revenue + welfare + contribution)`;
    db.query(sql, addSalary, (err, res) => {
        if (err) throw err
    })
    res.redirect('salaryadded');
})
// Set static folder
app.use(express.static(path.join(__dirname, 'public')))
// REST API
app.use('/api/employee', require('./routes/api/employee'));
app.get('*', function(req, res){
    res.status(404).render('404', {
        msg: 'Sorry, Something went wrong'
    });
});
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server runnig on port: ${PORT}`));

